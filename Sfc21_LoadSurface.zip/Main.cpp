// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_dwCreationWidth			= 1024;
	m_dwCreationHeight			=  768;
	strcpy(m_strClassName, TEXT( "Mck" ));

	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pD3DXFont	= NULL;

	m_pTx		= NULL;
	m_pTxSf		= NULL;

	m_pOffScreen= NULL;
}



HRESULT CMain::Init()
{
	HRESULT hr=-1;

	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE, "Arial"
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;


	return S_OK;
}



HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);

	return S_OK;
}


HRESULT CMain::Restore()
{
	HRESULT hr = 0;

	m_pD3DXFont->OnResetDevice();

	// �ؽ�ó ���� �� �ؽ�ó�� ���ǽ��� �� �����ϴ� ���
	{
		D3DXIMAGE_INFO		Img;

		hr=D3DXCreateTextureFromFileEx(m_pd3dDevice
			, "Texture/Snow.jpg"
			, D3DX_DEFAULT
			, D3DX_DEFAULT
			, 1
			, 0
			, D3DFMT_UNKNOWN
			, D3DPOOL_DEFAULT
			, D3DX_FILTER_NONE
			, D3DX_FILTER_NONE
			, 0
			, &Img
			, NULL
			, &m_pTx);

		
		if (FAILED(hr))
			return hr;

		RECT rt={0,0, Img.Width, Img.Height};

		hr = m_pTx->GetSurfaceLevel( 0, &m_pTxSf);
	}


	// ���ǽ��� Off Screen�� ���� �ε� �ϴ� ���
	{
		hr = m_pd3dDevice->CreateOffscreenPlainSurface(1024
													, 768
													, D3DFMT_X8R8G8B8
													, D3DPOOL_DEFAULT
													, &m_pOffScreen
													, 0);

		hr = D3DXLoadSurfaceFromFile(m_pOffScreen
									, 0, 0
									, "Texture/Snow.jpg"
									, 0, D3DX_DEFAULT
									, 0, 0);

		if (FAILED(hr))
			return hr;
	}

	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	SAFE_RELEASE(	m_pTx	);
	SAFE_RELEASE(	m_pTxSf	);
	SAFE_RELEASE(	m_pOffScreen	);

	return S_OK;
}



HRESULT CMain::FrameMove()
{
	return S_OK;
}




HRESULT CMain::Render()
{
	HRESULT hr=-1;

	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	LPDIRECT3DSURFACE9	pSf = NULL;

	RECT rtS={100, 100,  800, 600};
	RECT rtT={10, 100, 500, 500};
	m_pd3dDevice->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pSf);

	hr = D3DXLoadSurfaceFromSurface(pSf, 0, &rtT, m_pTxSf, 0, &rtS, D3DX_FILTER_NONE, 0);

	
	rtT.left=500;
	rtT.right=rtT.left +500;
	hr = m_pd3dDevice->StretchRect(m_pOffScreen, &rtS, pSf, &rtT, D3DTEXF_NONE);
	pSf->Release();

	
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);


	RenderText();

	// End the scene.
	m_pd3dDevice->EndScene();

	return S_OK;
}


HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= {0};

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	RECT rc={ 10, 10, m_d3dsdBackBuffer.Width - 20, 10+30};
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rc, 0, fontColor );

	return S_OK;
}


LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				RECT rc;
				GetClientRect( hWnd, &rc );
				ReleaseDC( hWnd, hDC );
			}

			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}


