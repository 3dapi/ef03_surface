// File: Main.cpp
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


// �����ũ��
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState

typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;


D3DXVECTOR3 g_vDir;


inline FLOAT HeightField( FLOAT x, FLOAT y )
{
	return 9*(cosf(x/20+0.2f)*cosf(y/15-0.2f)+1.0f);
}


// Desc: Callback function for sorting trees in back-to-front order

int __cdecl TreeSortCB( const VOID* arg1, const VOID* arg2 )
{
	Tree* p1 = (Tree*)arg1;
	Tree* p2 = (Tree*)arg2;

	FLOAT d1 = p1->vPos.x * g_vDir.x + p1->vPos.z * g_vDir.z;
	FLOAT d2 = p2->vPos.x * g_vDir.x + p2->vPos.z * g_vDir.z;
	if (d1 < d2)
		return +1;

	return -1;
}


TCHAR* g_strTreeTextures[] =
{
	_T("Texture/Tree02S.dds"),
	_T("Texture/Tree35S.dds"),
	_T("Texture/Tree01S.dds"),
};



CMain::CMain()
{
	m_strWindowTitle    = _T("Billboard: D3D Billboarding Example");
	m_d3dEnumeration.AppUsesDepthBuffer = TRUE;
	m_d3dEnumeration.AppMinStencilBits	= 8;
	m_d3dEnumeration.AppMinDepthBits	= 24;


	m_pEft		= NULL;
}



BOOL CMain::IsTreePositionValid( DWORD iTree )
{
	FLOAT x = m_Trees[iTree].vPos.x;
	FLOAT z = m_Trees[iTree].vPos.z;

	for( DWORD i=0; i < iTree; i++ )
	{
		double fDeltaX = fabs( x - m_Trees[i].vPos.x );
		double fDeltaZ = fabs( z - m_Trees[i].vPos.z );

		if( 3.0 > pow( fDeltaX, 2 ) + pow( fDeltaZ, 2 ) )
			return FALSE;
	}

	return TRUE;
}


HRESULT CMain::OneTimeSceneInit()
{
	// Initialize the tree data
	for( WORD i=0; i<NUM_TREES; i++ )
	{
		do
		{
			// Position the trees randomly
			FLOAT fTheta  = 2.0f*D3DX_PI*(FLOAT)rand()/RAND_MAX;
			FLOAT fRadius = 25.0f + 55.0f * (FLOAT)rand()/RAND_MAX;
			m_Trees[i].vPos.x  = fRadius * sinf(fTheta);
			m_Trees[i].vPos.z  = fRadius * cosf(fTheta);
			m_Trees[i].vPos.y  = HeightField( m_Trees[i].vPos.x, m_Trees[i].vPos.z );
		}
		while( !IsTreePositionValid( i ) );

		// Size the trees randomly
		FLOAT fWidth  = 1.0f + 0.2f * (FLOAT)(rand()-rand())/RAND_MAX;
		FLOAT fHeight = 1.4f + 0.4f * (FLOAT)(rand()-rand())/RAND_MAX;

		// Each tree is a random color between red and green
		DWORD r = (255-190) + (DWORD)(190*(FLOAT)(rand())/RAND_MAX);
		DWORD g = (255-190) + (DWORD)(190*(FLOAT)(rand())/RAND_MAX);
		DWORD b = 0;
		DWORD dwColor = 0xff000000 + (r<<16) + (g<<8) + (b<<0);

		m_Trees[i].v[0].p     = D3DXVECTOR3(-fWidth, 0*fHeight, 0.0f );
		m_Trees[i].v[0].color = dwColor;
		m_Trees[i].v[0].tu    = 0.0f;   m_Trees[i].v[0].tv = 1.0f;
		m_Trees[i].v[1].p     = D3DXVECTOR3(-fWidth, 2*fHeight, 0.0f  );
		m_Trees[i].v[1].color = dwColor;
		m_Trees[i].v[1].tu    = 0.0f;   m_Trees[i].v[1].tv = 0.0f;
		m_Trees[i].v[2].p     = D3DXVECTOR3( fWidth, 0*fHeight, 0.0f  );
		m_Trees[i].v[2].color = dwColor;
		m_Trees[i].v[2].tu    = 1.0f;   m_Trees[i].v[2].tv = 1.0f;
		m_Trees[i].v[3].p     = D3DXVECTOR3( fWidth, 2*fHeight, 0.0f  );
		m_Trees[i].v[3].color = dwColor;
		m_Trees[i].v[3].tu    = 1.0f;   m_Trees[i].v[3].tv = 0.0f;

		// Pick a random texture for the tree
		m_Trees[i].dwTreeTexture = (DWORD)( ( NUMTREETEXTURES * rand() ) / (FLOAT)RAND_MAX );
	}

	return S_OK;
}



HRESULT CMain::InitDeviceObjects()
{
	HRESULT hr;

	D3DXCreateSprite(m_pd3dDevice, &m_pSprite);


	D3DXFONT_DESC hFont =
	{
		16, 0, FW_NORMAL
		, 1, 0
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		
		, ANTIALIASED_QUALITY
		, FF_DONTCARE, "Arial"
	};

	D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont);



	m_pSkyBox      = new CD3DMesh();
	m_pTerrain     = new CD3DMesh();
	m_pTreeVB      = NULL;


	DWORD i=0;

	for(i=0; i<NUMTREETEXTURES; i++ )
		m_pTreeTextures[i] = NULL;


	// Create the tree textures
	for(i=0; i<NUMTREETEXTURES; ++i )
	{
		hr = D3DXCreateTextureFromFileEx( m_pd3dDevice, g_strTreeTextures[i], 
                D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, 
                D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR, 
                D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR, 0, NULL, NULL, &m_pTreeTextures[i] );

		if( FAILED(hr))
			return hr;
	}

	// Create a quad for rendering each tree
	if( FAILED( hr = m_pd3dDevice->CreateVertexBuffer( NUM_TREES*4*sizeof(TREEVERTEX),
		D3DUSAGE_WRITEONLY, TREEVERTEX::FVF,
		D3DPOOL_MANAGED, &m_pTreeVB, NULL ) ) )
	{
		return hr;
	}

	// Copy tree mesh data into vertexbuffer
	TREEVERTEX* v;
	m_pTreeVB->Lock( 0, 0, (void**)&v, 0);

	INT iTree;
	DWORD dwOffset = 0;
	for( iTree = 0; iTree < NUM_TREES; iTree++ )
	{
		memcpy( &v[dwOffset], m_Trees[iTree].v, 4*sizeof(TREEVERTEX) );
		m_Trees[iTree].dwOffset = dwOffset;
		dwOffset += 4;
	}

	m_pTreeVB->Unlock();

	// Load the skybox
	if( FAILED( m_pSkyBox->Create( m_pd3dDevice, _T("xFile/SkyBox2.x") ) ) )
		return D3DAPPERR_MEDIANOTFOUND;

	// Load the terrain
	if( FAILED( m_pTerrain->Create( m_pd3dDevice, _T("xFile/SeaFloor.x") ) ) )
		return D3DAPPERR_MEDIANOTFOUND;

	// Add some "hilliness" to the terrain
	LPDIRECT3DVERTEXBUFFER9 pVB;
	if( SUCCEEDED( m_pTerrain->GetSysMemMesh()->GetVertexBuffer( &pVB ) ) )
	{
		struct VERTEX { FLOAT x,y,z,tu,tv; };
		VERTEX* pVertices;
		DWORD   dwNumVertices = m_pTerrain->GetSysMemMesh()->GetNumVertices();

		pVB->Lock( 0, 0, (void**)&pVertices, 0);

		for( DWORD i=0; i<dwNumVertices; i++ )
			pVertices[i].y = HeightField( pVertices[i].x, pVertices[i].z );

		pVB->Unlock();
		pVB->Release();
	}





 	LPD3DXBUFFER pErr;

	hr = D3DXCreateEffectFromFile(m_pd3dDevice, "hlsl.fx", NULL, NULL, D3DXSHADER_DEBUG , NULL, &m_pEft, &pErr );

    if( FAILED( hr))
	{
		if(pErr)
		{
			char* sErr = (char*)pErr->GetBufferPointer();

			MessageBox(m_hWnd, sErr, "Err", MB_ICONWARNING|MB_OK);

			SAFE_RELEASE(	pErr	);
		}

		return -1;
	}

	return S_OK;
}




HRESULT CMain::DeleteDeviceObjects()
{
	SAFE_RELEASE(	m_pSprite	);
	SAFE_RELEASE(	m_pD3DXFont		);

	m_pTerrain->Destroy();
	m_pSkyBox->Destroy();

	SAFE_DELETE( m_pTerrain );
	SAFE_DELETE( m_pSkyBox );


	for( DWORD i=0; i<NUMTREETEXTURES; i++ )
		SAFE_RELEASE( m_pTreeTextures[i] );

	SAFE_RELEASE( m_pTreeVB );


	SAFE_RELEASE( m_pEft );

	return S_OK;
}



HRESULT CMain::RestoreDeviceObjects()
{
	// ȭ�� ũ��� ������ �ؽ�ó�� ����
	m_Rf1.Create(m_pd3dDevice, m_dwCreationWidth, m_dwCreationHeight);
	m_Rf2.Create(m_pd3dDevice, m_dwCreationWidth, m_dwCreationHeight);


	// ����Ʈ
	m_pEft->OnResetDevice();





	m_pSprite->OnResetDevice();
	m_pD3DXFont->OnResetDevice();







	// Restore the device objects for the meshes and fonts
	m_pTerrain->RestoreDeviceObjects( m_pd3dDevice );
	m_pSkyBox->RestoreDeviceObjects( m_pd3dDevice );



	// Set the transform matrices (view and world are updated per frame)
	D3DXMATRIX matProj;
	FLOAT fAspect = m_d3dsdBackBuffer.Width / (FLOAT)m_d3dsdBackBuffer.Height;
	D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 1.0f, 5000.0f );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

	// Set up the default texture states
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_CLAMP );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_CLAMP );

	m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,     FALSE );

	return S_OK;
}




HRESULT CMain::InvalidateDeviceObjects()
{
	m_pSprite->OnLostDevice();
	m_pD3DXFont->OnLostDevice();

	m_Rf1.Destroy();
	m_Rf2.Destroy();

	m_pEft->OnLostDevice();

	m_pTerrain->InvalidateDeviceObjects();
	m_pSkyBox->InvalidateDeviceObjects();


	return S_OK;
}



HRESULT CMain::FrameMove()
{
	// Get the eye and lookat points from the camera's path
	D3DXVECTOR3 vUpVec( 0.0f, 1.0f, 0.0f );
	D3DXVECTOR3 vEyePt;
	D3DXVECTOR3 vLookatPt;
	FLOAT fTime = m_fTime * 0.1f;

	vEyePt.x = 30.0f*cosf( 0.8f * ( fTime ) );
	vEyePt.z = 30.0f*sinf( 0.8f * ( fTime ) );
	vEyePt.y = 4 + HeightField( vEyePt.x, vEyePt.z );

	vLookatPt.x = 30.0f*cosf( 0.8f * ( fTime + 0.5f ) );
	vLookatPt.z = 30.0f*sinf( 0.8f * ( fTime + 0.5f ) );
	vLookatPt.y = vEyePt.y - 1.0f;

	// Set the app view matrix for normal viewing
	D3DXMATRIX matView;
	D3DXMatrixLookAtLH( &matView, &vEyePt, &vLookatPt, &vUpVec );
	m_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

	// Set up a rotation matrix to orient the billboard towards the camera.
	D3DXVECTOR3 vDir = vLookatPt - vEyePt;
	if( vDir.x > 0.0f )
		D3DXMatrixRotationY( &m_matBillboardMatrix, -atanf(vDir.z/vDir.x)+D3DX_PI/2 );
	else
		D3DXMatrixRotationY( &m_matBillboardMatrix, -atanf(vDir.z/vDir.x)-D3DX_PI/2 );
	g_vDir   = vDir;

	// Sort trees in back-to-front order
	qsort( m_Trees, NUM_TREES, sizeof(Tree), TreeSortCB );

	// Store vectors used elsewhere
	m_vEyePt = vEyePt;




	// Texture�� ������
	m_Rf1.BeginScene();
	{
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0, 1.0f, 0L );

		// Center view matrix for skybox and disable zbuffer
		D3DXMATRIX matViewSave;
		m_pd3dDevice->GetTransform( D3DTS_VIEW, &matViewSave );
		matView = matViewSave;
		matView._41 = 0.0f; matView._42 = -0.3f; matView._43 = 0.0f;
		m_pd3dDevice->SetTransform( D3DTS_VIEW,      &matView );
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
		// Some cards do not disable writing to Z when
		// D3DRS_ZENABLE is FALSE. So do it explicitly
		m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, FALSE );

		// Render the skybox
		m_pSkyBox->Render( m_pd3dDevice );

		// Restore the render states
		m_pd3dDevice->SetTransform( D3DTS_VIEW,      &matViewSave );
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);

		// Draw the terrain
		m_pTerrain->Render( m_pd3dDevice );

		// Draw the trees
		DrawTrees();
	}
	m_Rf1.EndScene();



	m_Rf2.BeginScene();
	{
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xFFFFFFFF, 1.0f, 0L );

		// ����
		m_pEft->SetTechnique( "TShader" );

		m_pEft->SetFloat("TEXTURE_W", (FLOAT)m_dwCreationWidth);
		m_pEft->SetFloat("TEXTURE_H", (FLOAT)m_dwCreationHeight);
		m_pEft->SetTexture("TexDif", m_Rf1.GetTexture());
		
		m_pEft->Begin(NULL, 0);
		m_pEft->BeginPass(0);

			TVERTEX Vertex1[4] =
			{
				//   x    y     z    u  v
				{-1.0f, +1.0f, 0.f,  0, 0},
				{+1.0f, +1.0f, 0.f,  1, 0},
				{+1.0f, -1.0f, 0.f,  1, 1},
				{-1.0f, -1.0f, 0.f,  0, 1},
			};

			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex1, sizeof( TVERTEX ) );

		m_pEft->EndPass();
		m_pEft->End();
	}
	m_Rf2.EndScene();

	return S_OK;
}




HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL
						, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER
						, 0, 1.0f, 0L );

	// Begin the scene
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	LPDIRECT3DTEXTURE9	pTx = NULL;
	RECT				rc;


	SetRect(&rc, 0,0, m_dwCreationWidth, m_dwCreationHeight);

	pTx = m_Rf1.GetTexture();

	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND);
	m_pSprite->Draw(pTx, &rc, NULL, &D3DXVECTOR3(0, 0, 0), D3DXCOLOR(1,1,1,1.f));


	pTx = m_Rf2.GetTexture();


	RECT	rcImg;

	SetRect(&rcImg,   0,  0, 400, 600);
	m_pSprite->Draw(pTx, &rcImg, NULL, NULL, D3DXCOLOR(1,1,1,1.f));

	m_pSprite->End();



	D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH] = TEXT("");
	RECT rct;
	ZeroMemory( &rct, sizeof(rct) );

	rct.left   = 2;
	rct.right  = m_d3dsdBackBuffer.Width - 20;

	// Output display stats
	INT nNextLine = 0;

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );
	nNextLine = 0; rct.top = nNextLine; rct.bottom = rct.top + 20;
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );


	// End the scene.
	m_pd3dDevice->EndScene();

	return S_OK;
}







// Name: DrawTrees()
// Desc:

HRESULT CMain::DrawTrees()
{
	// Set diffuse blending for alpha set in vertices.
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
	m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

	// Enable alpha testing (skips pixels with less than a certain alpha.)
	if( m_d3dCaps.AlphaCmpCaps & D3DPCMPCAPS_GREATEREQUAL )
	{
		m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );
	}

	// Loop through and render all trees
	m_pd3dDevice->SetStreamSource( 0, m_pTreeVB, 0, sizeof(TREEVERTEX) );
	m_pd3dDevice->SetFVF( TREEVERTEX::FVF );
	for( DWORD i=0; i<NUM_TREES; i++ )
	{
		// Quick culling for trees behind the camera
		// This calculates the tree position relative to the camera, and
		// projects that vector against the camera's direction vector. A
		// negative dot product indicates a non-visible tree.
		if( 0 > ( m_Trees[i].vPos.x - m_vEyePt.x ) * g_vDir.x +
			( m_Trees[i].vPos.z - m_vEyePt.z ) * g_vDir.z )
		{
			break;
		}

		// Set the tree texture
		m_pd3dDevice->SetTexture( 0, m_pTreeTextures[m_Trees[i].dwTreeTexture] );

		// Translate the billboard into place
		m_matBillboardMatrix._41 = m_Trees[i].vPos.x;
		m_matBillboardMatrix._42 = m_Trees[i].vPos.y;
		m_matBillboardMatrix._43 = m_Trees[i].vPos.z;
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_matBillboardMatrix );

		// Render the billboard
		m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, m_Trees[i].dwOffset, 2 );
	}

	// Restore state
	D3DXMATRIX  matWorld;
	D3DXMatrixIdentity( &matWorld );
	m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );


	return S_OK;
}
