// Implementation of the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CEfSurface::CEfSurface()
{
	m_pDev		= NULL;
	m_pSpt		= NULL;

	m_pDevT		= NULL;
	m_pDevD		= NULL;

	m_pBlrTx	= NULL;
	m_pBlrSf	= NULL;
	
	m_pAccTx	= NULL;
	m_pAccSf	= NULL;
}


CEfSurface::~CEfSurface()
{
	Destroy();
}


INT CEfSurface::Create(PDEV pDev, PDSP pSpt)
{
	m_pDev	= pDev;
	m_pSpt	= pSpt;

	//ȭ�� ũ�� ���

	IDirect3DSurface9*	pBackSurface=NULL;
	D3DSURFACE_DESC		dsc;

	if(FAILED(m_pDev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackSurface)))
		return-1;
		
	pBackSurface->GetDesc( &dsc );
	pBackSurface->Release();

	m_iScnW = dsc.Width;
	m_iScnH = dsc.Height;


	DWORD	alphaColor = D3DXCOLOR(1.F, 1.F, 1.F, .8F);
	FLOAT	c=-1.f;

	m_pVtxBlr[0] = VtxwDUV1(c+	0.f,		0.f,	0.f, 0,0, alphaColor);
	m_pVtxBlr[1] = VtxwDUV1(c+m_iScnW,		0.f,	0.f, 1,0, alphaColor); 
	m_pVtxBlr[2] = VtxwDUV1(c+	0.f,	m_iScnH,	0.f, 0,1, alphaColor); 
	m_pVtxBlr[3] = VtxwDUV1(c+m_iScnW,	m_iScnH,	0.f, 1,1, alphaColor);

	
	m_pVtxAcc[0] = VtxwDUV1(    0.f,		0.f,	0.f, 0,0);
	m_pVtxAcc[1] = VtxwDUV1(m_iScnW,		0.f,	0.f, 1,0); 
	m_pVtxAcc[2] = VtxwDUV1(    0.f,	m_iScnH,	0.f, 0,1); 
	m_pVtxAcc[3] = VtxwDUV1(m_iScnW,	m_iScnH,	0.f, 1,1);


	m_pVtxRnd[0] = VtxwDUV1(	     -1.f,		    -1.f, 0.f, 0.0005f,0.05f);
	m_pVtxRnd[1] = VtxwDUV1( m_iScnW+ 1.f,		    -1.f, 0.f, 0.9995f,0.05f);
	m_pVtxRnd[2] = VtxwDUV1(		 -1.f,	m_iScnH+ 1.f, 0.f, 0.0005f,0.95f);
	m_pVtxRnd[3] = VtxwDUV1( m_iScnW+ 1.f,	m_iScnH+ 1.f, 0.f, 0.9995f,0.95f);


	return 0;
}

void CEfSurface::Destroy()
{
}



INT CEfSurface::Restore()
{
	HRESULT hr=-1;

	// 1. Device�� Ÿ��, ���̽��ٽ� ������ �����͸� ���� �´�.
	m_pDev->GetRenderTarget(0, &m_pDevT);
	m_pDev->GetDepthStencilSurface(&m_pDevD);
	

	// 2. ȭ�� ����� �ؽ�ó�� �����Ѵ�.
	if(FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iScnW
									, m_iScnH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_A8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pBlrTx)))
		return -1;


	// Accumulate texture�� ���İ� ����� �ȴ�.
	if(FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iScnW
									, m_iScnH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_X8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pAccTx)))
		return -1;

	

	// 3. �ؽ�ó�� ���ǽ��� ��� �´�.
	m_pBlrTx->GetSurfaceLevel(0,&m_pBlrSf);
	m_pAccTx->GetSurfaceLevel(0,&m_pAccSf);

	return 0;
}


void CEfSurface::Invalidate()
{
	SAFE_RELEASE(	m_pDevT		);
	SAFE_RELEASE(	m_pDevD		);

	SAFE_RELEASE(	m_pBlrSf	);
	SAFE_RELEASE(	m_pBlrTx	);
	
	SAFE_RELEASE(	m_pAccSf	);
	SAFE_RELEASE(	m_pAccTx	);
}


INT CEfSurface::FrameMove()
{
	HRESULT	hr=0;

	// 1. ���� Ÿ���� Blur �ؽ�ó�� �����Ѵ�.
	m_pDev->SetRenderTarget(0,m_pBlrSf);

	m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L );


	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0,  D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);


	// 1. Blur �ؽ�ó�� ����� ������
	SAFE_RENDER(	GMAIN->m_pGrid	);
	SAFE_RENDER(	GMAIN->m_pField	);
		
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
	m_pDev->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
	

	// 2. Blur �ؽ�ó�� ���ĸ� �����ؼ� ���� ���(�ִ��� ����)�� ������
	m_pDev->SetTexture(0,m_pAccTx);
	m_pDev->SetFVF( VtxwDUV1::FVF );
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2,m_pVtxBlr,sizeof(VtxwDUV1));


	// 3. ������ ŸŶ�� �������۷� ��ȯ
	m_pDev->SetRenderTarget(0,m_pAccSf);

	// ���� ������ ��� ����
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE);

	
	// 4. ���� �ؽ�ó�� �׸���.
	m_pDev->SetTexture(0,m_pBlrTx);
	m_pDev->SetFVF( VtxwDUV1::FVF );
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2, m_pVtxAcc, sizeof(VtxwDUV1));

	
	// 5. ���� Ÿ���� ������� ���� ���´�.
	m_pDev->SetRenderTarget(0,m_pDevT);
	m_pDev->SetDepthStencilSurface(m_pDevD);

	return 0;
}


void CEfSurface::Render()
{
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE);

	//���� Blur �ؽ�ó�� ������
	m_pDev->SetTexture(0,m_pAccTx);
	m_pDev->SetFVF( VtxwDUV1::FVF );
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2,m_pVtxRnd,sizeof(VtxwDUV1));
}


