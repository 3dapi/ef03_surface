// Interface for the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _EfSurface_H_
#define _EfSurface_H_


typedef D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;

typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPD3DXSPRITE						PDSP;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef LPDIRECT3DSURFACE9					PDSF;


class CEfSurface
{
public:
	struct VtxwDUV1
	{
		VEC4	p;
		DWORD	d;
		FLOAT	u,v;

		VtxwDUV1()	{}
		VtxwDUV1(FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT U, FLOAT V
				, DWORD D=0xFFFFFFFF) : p(X,Y,Z,1.F),u(U),v(V),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1), };
	};


protected:
	PDEV		m_pDev;
	PDSP		m_pSpt;

	PDSF		m_pDevD;														// Back buffer Depth and stencil
	PDSF		m_pDevT;														// Back buffer target
	
	PDTX		m_pBlrTx;														// Target blur texture
	PDSF		m_pBlrSf;														// Target blur surface

	PDTX		m_pAccTx;														// Accumulate blur texture
	PDSF		m_pAccSf;														// Accumulate blur surface

	INT			m_iScnW;
	INT			m_iScnH;

	VtxwDUV1	m_pVtxBlr[4];
	VtxwDUV1	m_pVtxAcc[4];
	VtxwDUV1	m_pVtxRnd[4];

public:
	CEfSurface();
	virtual ~CEfSurface();

	INT		Create(PDEV pDev, PDSP pSpt);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif

