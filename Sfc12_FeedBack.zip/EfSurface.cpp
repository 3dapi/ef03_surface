// Implementation of the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


// ����: Multi Sampling ������ �ȵǾ�� ������ ����
//


CEfSurface::CEfSurface()
{
	m_pDev		= NULL;

	m_pDevT		= NULL;
	m_pDevD		= NULL;

	m_pOrgTx	= NULL;
	m_pOrgSf	= NULL;

	m_pSctTx	= NULL;
	m_pSctSf	= NULL;

	m_pScnTx	= NULL;
	m_pScnSf	= NULL;
}


CEfSurface::~CEfSurface()
{
	Destroy();
}


INT CEfSurface::Create(PDEV pDev)
{
	m_pDev	= pDev;

	//ȭ�� ũ�� ���

	IDirect3DSurface9*	pBackSurface=NULL;
	D3DSURFACE_DESC		dsc;

	if(FAILED(m_pDev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackSurface)))
		return-1;
		
	pBackSurface->GetDesc( &dsc );
	pBackSurface->Release();

	m_iTxW = dsc.Width;
	m_iTxH = dsc.Height;
	

	m_pVx1[0] = VtxDUV1(-1.0f,  1.f, 0.f, 0.f, 0.f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx1[1] = VtxDUV1( 1.0f,  1.f, 0.f, 1.f, 0.f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx1[2] = VtxDUV1(-1.0f, -1.f, 0.f, 0.f, 1.f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx1[3] = VtxDUV1( 1.0f, -1.f, 0.f, 1.f, 1.f, D3DCOLOR_ARGB(200,0,0,0));


	m_pVx2[0] = VtxDUV1(-2.7f,  2.f, 0.f, .15f, .15f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx2[1] = VtxDUV1( 2.7f,  2.f, 0.f, .85f, .15f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx2[2] = VtxDUV1(-2.7f, -2.f, 0.f, .15f, .85f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx2[3] = VtxDUV1( 2.7f, -2.f, 0.f, .85f, .85f, D3DCOLOR_ARGB(200,0,0,0));

	

	m_fFeedbackRotation        = 0.0f;
	m_fFeedbackRotationAccel   = 10.0f;
	m_fImageRotation           = 0.0f;
	m_fImageRotationAccel      = 30.0f;
	m_fFeedbackScale           = 10.0f;
	m_fFeedbackScaleAccel      = 1.0f;


	VEC3 vEye = VEC3( 0.0f, 0.0f, -2.f );
	VEC3 vAt  = VEC3( 0.0f, 0.0f, 0.0f );
	VEC3 vUp  = VEC3( 0.0f, 1.0f, 0.0f );
	D3DXMatrixLookAtLH( &m_mtViw, &vEye, &vAt, &vUp );

	FLOAT fAspect = FLOAT(m_iTxW)/ FLOAT(m_iTxH);
	D3DXMatrixPerspectiveFovLH( &m_mtPrj, D3DXToRadian(90), fAspect, 0.1f, 100.0f );
	
	return 0;
}

void CEfSurface::Destroy()
{
}



INT CEfSurface::Restore()
{
	HRESULT hr=0;

	// 1. Device�� Ÿ��, ���̽��ٽ� ������ �����͸� ���� �´�.
	m_pDev->GetRenderTarget(0, &m_pDevT);
	m_pDev->GetDepthStencilSurface(&m_pDevD);
	

	// 2. ȭ�� ����� ����, ��ũ��ġ, �����  �ؽ�ó�� �����Ѵ�.
	if (FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iTxW
									, m_iTxH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_A8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pOrgTx)))
		return -1;

	
	if (FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iTxW
									, m_iTxH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_A8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pSctTx)))
		return -1;
	

	if (FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iTxW
									, m_iTxH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_A8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pScnTx)))
		return -1;

	

	// 3. ����, ��ũ��ġ, ����� �ؽ�ó�� ���ǽ��� �����´�.
	m_pOrgTx->GetSurfaceLevel(0, &m_pOrgSf);
	m_pSctTx->GetSurfaceLevel(0, &m_pSctSf);
	m_pScnTx->GetSurfaceLevel(0, &m_pScnSf);

	return 0;
}


void CEfSurface::Invalidate()
{
	SAFE_RELEASE(	m_pDevT		);
	SAFE_RELEASE(	m_pDevD		);

	SAFE_RELEASE(	m_pOrgSf	);
	SAFE_RELEASE(	m_pOrgTx	);

	SAFE_RELEASE(	m_pSctSf	);
	SAFE_RELEASE(	m_pSctTx	);

	SAFE_RELEASE(	m_pSctTx	);
	SAFE_RELEASE(	m_pOrgTx	);

	SAFE_RELEASE(	m_pScnTx	);
	SAFE_RELEASE(	m_pScnSf	);
}


INT CEfSurface::FrameMove()
{
	HRESULT	hr=0;

	// 1. Update data
	FLOAT fSecsPerFrame = GMAIN->GetTimeElapsed()*.01f;

	if (fSecsPerFrame < 0.0001f)
	{
		fSecsPerFrame = 0.0001f;
	}
		
	m_fFeedbackRotation += m_fFeedbackRotationAccel*fSecsPerFrame;
	if (m_fFeedbackRotation > 100.0f) m_fFeedbackRotationAccel = -5.0f;
	if (m_fFeedbackRotation < -100.0f) m_fFeedbackRotationAccel = 5.0f;
	
	m_fImageRotation += m_fImageRotationAccel*fSecsPerFrame;
	if (m_fImageRotation > 100.0f) m_fImageRotationAccel = -100.0f;
	if (m_fImageRotation < -100.0f) m_fImageRotationAccel = 100.0f;
	
	m_fFeedbackScale += m_fFeedbackScaleAccel*fSecsPerFrame;

	if (m_fFeedbackScale > 95.0f)
		m_fFeedbackScaleAccel = -10.1f;

	if (m_fFeedbackScale < 5.0f)
		m_fFeedbackScaleAccel = 10.1f;

	
	{
		// 2. ��ũ��ġ ���Ǹ� ������۷� ����
		m_pDev->SetRenderTarget(0, m_pSctSf);

		
		// 3. ������ ���� ����
		m_pDev->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
		m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
		m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
		
		
		// 4. Į��� ������ ȥ���� ����
		m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
		m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
		m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );


		// 5. ����̽��� Ŭ����.
		m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x000000, 1.0f, 0L );

		
		// ��ũ��ġ ���񽺿� ������
		// ���� ������ ����Ͽ� �ȼ��� 1:1 ������
		MATA	mtPrj;

		MATA	mtScl;
		MATA	mtRot;
		MATA	mtWld;

		D3DXMatrixOrthoLH(&mtPrj, (FLOAT)m_iTxW, (FLOAT)m_iTxH, 0.0, 100.0);


		D3DXMatrixRotationZ(&mtRot, m_fFeedbackRotation);
		D3DXMatrixScaling(&mtScl, m_iTxW/1.8f, m_iTxH/1.8f, 1.0);
		D3DXMatrixMultiply(&mtWld, &mtRot, &mtScl);


		m_pDev->SetTransform( D3DTS_VIEW, &m_mtViw );
		m_pDev->SetTransform( D3DTS_PROJECTION, &mtPrj );
		m_pDev->SetTransform( D3DTS_WORLD, &mtWld );

		// ���� �̹����� �׸���.
		m_pDev->SetTexture(0, m_pOrgTx);
		m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
		m_pDev->SetFVF( VtxDUV1::FVF );
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx1, sizeof(VtxDUV1));



		// ȭ�� �̹����� �׸���.
		D3DXMatrixScaling(&mtScl, (FLOAT)m_iTxW/5, (FLOAT)m_iTxH/5, 1.0);
		D3DXMatrixRotationZ(&mtRot, m_fImageRotation);
		D3DXMatrixMultiply(&mtWld, &mtScl, &mtRot);

		m_pDev->SetTransform( D3DTS_WORLD, &mtWld );

		m_pDev->SetTexture(0, m_pScnTx);	
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx1, sizeof(VtxDUV1));
	}

	{
		// ������ ����(�̹����� ����� �� �� �ִ� �������)
		MATA mtWld;
		D3DXMatrixScaling(&mtWld, (FLOAT)m_iTxW/2.0f, (FLOAT)m_iTxH/2.0f, 1.0);


		// ���� �̹����� �׸� �ʿ䰡 �ִ�.
		// ���� �̹����� ������۷� �����ϵ� ����̽��� Ŭ���� ���� �ʴ´�.
		m_pDev->SetRenderTarget(0, m_pOrgSf);

		// �������� ���ǽ��� ��ũ��ġ ���ǽ��� ���´�.
		// ��⼭ �ǵ�� ȿ���� ��Ÿ����.

		// ���ĸ� ��ǻ��� ����
		m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );

		m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

		
		m_pDev->SetTransform( D3DTS_WORLD, &mtWld );
		m_pDev->SetTexture(0, m_pSctTx);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx1, sizeof(VtxDUV1));
	}
	
	
	{
		MATA	mtWld;
		MATA	mtViw;
		MATA	mtPrj;
		
		D3DXMatrixIdentity( &mtWld );
		mtPrj	= g_pApp->m_pCam->GetMatrixPrj();
		mtViw	= g_pApp->m_pCam->GetMatrixViw();

		m_pDev->SetRenderTarget(0, m_pScnSf);
		m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x00006688, 1.0f, 0L );
		
		m_pDev->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
		m_pDev->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		
		m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
		m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
		m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
		m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
		m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
		m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
		m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );


		m_pDev->SetTransform( D3DTS_WORLD, &mtWld );
		m_pDev->SetTransform(D3DTS_VIEW, &mtViw);
		m_pDev->SetTransform(D3DTS_PROJECTION, &mtPrj);


		SAFE_RENDER( GMAIN->m_pGrid		);
		SAFE_RENDER( GMAIN->m_pField	);
	}


	// ������ Ÿ�ϰ� ���� ���۸� �� ������ ����̽� ���� ���ۿ� ����̽� ���۷� �ٲ۴�.
	m_pDev->SetRenderTarget(0, m_pDevT);
	m_pDev->SetDepthStencilSurface(m_pDevD);

	return 0;
}


void CEfSurface::Render()
{
	D3DXMATRIX	mtViw;
	D3DXMATRIX	mtPrj;
	m_pDev->GetTransform( D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform( D3DTS_PROJECTION, &mtPrj);

	
	m_pDev->SetTransform( D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform( D3DTS_PROJECTION, &m_mtPrj);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );

	m_pDev->SetTexture( 0, m_pOrgTx);
	m_pDev->SetFVF( VtxDUV1::FVF );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx2, sizeof(VtxDUV1));

	m_pDev->SetTransform( D3DTS_VIEW, &mtViw);
	m_pDev->SetTransform( D3DTS_PROJECTION, &mtPrj);
}