// Interface for the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _EfSurface_H_
#define _EfSurface_H_


typedef D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef LPDIRECT3DSURFACE9					PDSF;


class CEfSurface
{
public:
	struct VtxDUV1
	{
		VEC3	p;
		DWORD	d;
		FLOAT	u, v;
		
		VtxDUV1(){}
		VtxDUV1(FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT U, FLOAT V
				, DWORD D=0xFFFFFFFF) : p(X,Y,Z),u(U),v(V),d(D){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1), };
	};


protected:
	PDEV		m_pDev;

	PDSF		m_pDevT;		// Device Color Buffer
	PDSF		m_pDevD;		// Device Depth Buffer

	// original and scratch textures
	PDTX		m_pOrgTx;
	PDSF		m_pOrgSf;		// Texture Surface1

	PDTX		m_pSctTx;
	PDSF		m_pSctSf;		// Texture Surface2

	PDTX		m_pScnTx;		// Screen Texture
	PDSF		m_pScnSf;		// Screen Surface
	


	// Scene
	VtxDUV1		m_pVx1[4];
	VtxDUV1		m_pVx2[4];
	
	// Transforms
	MATA		m_mtPos;
	MATA		m_mtViw;
	MATA		m_mtPrj;

	// width and height of texture image
	INT			m_iTxW;
	INT			m_iTxH;
	FLOAT		m_fFeedbackRotation;
	FLOAT		m_fFeedbackRotationAccel;
	FLOAT		m_fImageRotation;
	FLOAT		m_fImageRotationAccel;
	FLOAT		m_fFeedbackScale;
	FLOAT		m_fFeedbackScaleAccel;

public:
	CEfSurface();
	virtual ~CEfSurface();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif