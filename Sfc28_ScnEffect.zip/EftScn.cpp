// Implementation of the CEftScn class.
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//	Original Code
//
//	ripple_precalc.c
//	ripple.c
//	Drew Olbrich, 1992
//
//	This distortion effect approximates looking down at an
//	image through a layer of water.  The user can poke
//	at the water using the mouse, generating one or more
//	ripple patterns.
//
//	To create the effect, an large texture image is mapped
//	onto a mesh of polygons.  Only the texture coordinates of
//	the polygon vertices are distorted -- not the vertex
//	coordinates.
//
//	Port to OpenGL
//	Nate Robins, 1997
//
///////////////////////////////////////////////////////////////////////////////////////////////////
//
// Applied to Direct3D
// 2003-04-06
//
///////////////////////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "EftScn.h"


#define SAFE_FREE(p)	{ if(p) { free(p);        (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }



CEftScn::CEftScn()
{
	m_bRn	= FALSE;
	m_piX	= NULL;
	m_piY	= NULL;
	m_piT	= NULL;
	m_piM	= NULL;
	m_pfA	= NULL;
	m_pVtx	= NULL;

	m_pRpl	= NULL;

	m_pTxScn= NULL;
}


CEftScn::~CEftScn()
{
	Destroy();
}


void CEftScn::Destroy()
{
	int i;
	
	SAFE_FREE(	m_piX	);
	SAFE_FREE(	m_piY	);
	SAFE_FREE(	m_piT	);
	SAFE_FREE(	m_piM	);
	SAFE_FREE(	m_pfA	);
	SAFE_FREE(	m_pVtx	);
	
	if(m_pRpl)
	{
		for(i=0; i< m_iNX; ++i)
		{
			SAFE_FREE(m_pRpl[i]);
		}
	}

	SAFE_FREE(m_pRpl);
}

INT CEftScn::Create(void* p1/* =NULL */, void* p2/* =NULL */, void* p3/* =NULL */, void* p4/* =NULL */)
{
	m_pDev	= (PDEV)p1;



	D3DSURFACE_DESC dscC;
	PDSF	pSfC;

	m_pDev->GetRenderTarget(0, &pSfC);
	pSfC->GetDesc(&dscC);

	pSfC->Release();


	m_nScnW	= dscC.Width;
	m_nScnH	= dscC.Height;


	m_iW	= m_nScnW/4;
	m_iH	= m_nScnH/4;
	m_iNX	= 64;
	m_iNY	= 64;
	m_iL	= 1024;
	m_iC	= 10;
	m_fA	= .25f;
	m_fS	=  10.f;
	m_iN	=  20;

	int i;
	
	m_piX	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_piY	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_piT	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_piM	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_pfA	=(FLOAT*) calloc( m_iL , sizeof(FLOAT));
	
	m_pRpl = (EftRpl**) calloc (m_iNX , sizeof(EftRpl*));
	
	for(i=0; i< m_iNX; ++i)
		m_pRpl[i] = (EftRpl*) calloc (m_iNY , sizeof(EftRpl));
	
	VectorCal();
	AmpCal();
	VertexCal();
	
	m_pVtx =(VtxwDUV*) malloc( 6* m_iNX* m_iNY*sizeof(VtxwDUV));


	return 0;
}


INT CEftScn::FrameMove()
{
	if(!m_bRn)
		return 0;

	DWORD dwF = timeGetTime();
	

	if(dwF > (m_dwI+12000))
	{
		m_bRn = FALSE;
	}
	

	Dynamics();

	FLOAT fRX = FLOAT(m_nScnW)/m_iW;
	FLOAT fRY = FLOAT(m_nScnH)/m_iH;

	INT k=0;
	for(INT i=0; i< m_iNX-1; ++i)
	{
		for(INT j=0; j < m_iNY-1; ++j)
		{
			EftRpl * p00 = &m_pRpl[i+0][j+0];
			EftRpl * p10 = &m_pRpl[i+1][j+0];
			EftRpl * p01 = &m_pRpl[i+0][j+1];
			EftRpl * p11 = &m_pRpl[i+1][j+1];


			
			m_pVtx[k*6+0] =	VtxwDUV(p00->p.x * fRX, p00->p.y * fRY, 0.f, p00->c.x, p00->c.y);
			m_pVtx[k*6+1] =	VtxwDUV(p10->p.x * fRX, p10->p.y * fRY, 0.f, p10->c.x, p10->c.y);
			m_pVtx[k*6+2] =	VtxwDUV(p01->p.x * fRX, p01->p.y * fRY, 0.f, p01->c.x, p01->c.y);
			m_pVtx[k*6+3] =	VtxwDUV(p11->p.x * fRX, p11->p.y * fRY, 0.f, p11->c.x, p11->c.y);


			m_pVtx[k*6+4] =	m_pVtx[k*6+2];
			m_pVtx[k*6+5] =	m_pVtx[k*6+1];

			++k;
		}
	}

	return 0;
}


void CEftScn::Render()
{
	if(!m_bRn)
		return;

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);

	
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	
	m_pDev->SetRenderState( D3DRS_FOGENABLE, 	FALSE);
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
	m_pDev->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );
	
	m_pDev->SetTexture(0, m_pTxScn);
	m_pDev->SetFVF(VtxwDUV::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2*m_iNX*m_iNY, m_pVtx, sizeof(VtxwDUV));


	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
	m_pDev->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );

}


void CEftScn::Drop(INT nPosX, INT nPosY)
{
	INT index=0;
	
//	nPosX = 1 + rand()%(m_iW-2);
//	nPosY = 1 + rand()%(m_iH-2);
//	nPosX = m_iW/2;
//	nPosY = m_iH/2;
	
	while (m_piT[index] < m_piM[index] && index < m_iN)
		index++;
	
	if (index < m_iN)
	{
		m_piX[index] = INT(1.f*m_iNX*nPosX/m_iW);
		m_piY[index] = INT(1.f*m_iNY*nPosY/m_iH);
		m_piT[index] = INT(4.f*m_fS);
		m_piM[index] = DistanceMax(m_piX[index], m_piY[index]);
	}
}



void CEftScn::Dynamics()
{
	INT i, j, k;
	INT x, y;
	INT mi, mj;
	INT r;
	
	D3DXVECTOR2 s;
	FLOAT amp;
	
	for(i=0; i < m_iN; i++)
		m_piT[i] += INT(m_fS);
	
	for(i=0; i < m_iNX; i++)
	{
		for(j=0; j < m_iNY; j++)
		{
			m_pRpl[i][j].c = m_pRpl[i][j].t;
			
			for(k=0; k < m_iN; k++)
			{
				x = i - m_piX[k];
				y = j - m_piY[k];
				
				if (x < 0)
				{
					x *= -1;
					s.x = -1.f;
				}
				else
					s.x = 1.f;
				
				if (y < 0)
				{
					y *= -1;
					s.y = -1.f;
				}
				else
					s.y = 1.f;
				
				mi = x;
				mj = y;
				
				r = m_piT[k] - m_pRpl[mi][mj].r;
				
				if (r < 0)
					r = 0;
				
				
				if (r > m_iL - 1)
					r = m_iL - 1;
				
				amp = 1.f - 1.f*m_piT[k]/m_iL;
				amp *= amp;
				
				if (amp < 0.f)
					amp = 0.f;
				
				m_pRpl[i][j].c.x += m_pRpl[mi][mj].d.x * s.x * m_pfA[r] * amp;
				m_pRpl[i][j].c.y += m_pRpl[mi][mj].d.y * s.y * m_pfA[r] * amp;
			}
		}
	}
}



FLOAT CEftScn::Distance(INT x0, INT y0, INT x1, INT y1)
{
	FLOAT	f = FLOAT((x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1));
	return sqrtf(f);
}


INT CEftScn::DistanceMax(INT x, INT y)
{
	FLOAT d;
	FLOAT temp_d;
	
	d = Distance(x, y, 0, 0);
	temp_d = Distance(x, y, m_iNX, 0);
	
	if (temp_d > d)
		d = temp_d;
	
	temp_d = Distance(x, y, m_iNX, m_iNY);
	
	if (temp_d > d)
		d = temp_d;
	
	temp_d = Distance(x, y, 0, m_iNY);
	
	if (temp_d > d)
		d = temp_d;
	
	return INT((d/m_iNX)*m_iW + m_iL/6);
}



void CEftScn::VertexCal()
{
	INT i, j;
	
	m_iM = (INT)sqrt((double)(m_iH*m_iH + m_iW*m_iW));
	
	for(i=0; i < m_iN; i++)
	{
		m_piT[i] = m_iM + m_iL;
		m_piX[i] = 0;
		m_piY[i] = 0;
		m_piM[i] = 0;
	}
	
	for(i=0; i < m_iNX; i++)
	{
		for(j=0; j < m_iNY; j++)
		{
			m_pRpl[i][j].p = D3DXVECTOR2( i/(m_iNX - 1.f)*m_iW, j/(m_iNY - 1.f)*m_iH);
			m_pRpl[i][j].t = D3DXVECTOR2( i/(m_iNX - 1.f),    j/(m_iNY - 1.f));
		}
	}
}



void CEftScn::VectorCal()
{
	INT i, j;
	D3DXVECTOR2	p;
	FLOAT	l;
	
	for(i=0; i < m_iNX; i++)
	{
		for(j=0; j < m_iNY; j++)
		{
			p = D3DXVECTOR2( i/(m_iNX-1.f), j/(m_iNY-1.f) );
			l = D3DXVec2Length(&p);
			
			if (l == 0.f)
				p = D3DXVECTOR2(0.f, 0.f);
			
			else
				p /= l;
			
			
			m_pRpl[i][j].d = p;
			m_pRpl[i][j].r = (INT) (l*m_iW*2);
		}
	}
}


void CEftScn::AmpCal()
{
	INT i;
	FLOAT m_piT;
	FLOAT a;
	
	for(i=0; i < m_iL; i++)
	{
		m_piT = 1.f - i/FLOAT(m_iL);
		
		a = (1- cosf( m_piT * 6.283185307f*m_iC))* m_fA * powf(m_piT, 5);
		
		if (i == 0)
			a = 0.f;
		
		m_pfA[i] = a;
	}
}


void CEftScn::Reset(FLOAT X, FLOAT Y, float fAvgDeltaTime)
{
	INT nPosX = INT(X/4);
	INT nPosY = INT(Y/4);


	if(nPosX<2 || nPosX>(m_iW-3))
		return;

	if(nPosY<2 || nPosY>(m_iH-3))
		return;

	m_bRn = true;

	m_dwI = timeGetTime();


	m_fS = fAvgDeltaTime * 400;

	Drop(nPosX, nPosY);
}



void CEftScn::SetTexture(PDTX pTx)
{
	m_pTxScn = pTx;
}