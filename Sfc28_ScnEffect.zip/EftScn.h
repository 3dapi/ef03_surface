// Interface for the CEftScn class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _EFTRPL_H_
#define _EFTRPL_H_


typedef LPDIRECT3DDEVICE9		PDEV;
typedef LPDIRECT3DTEXTURE9		PDTX;
typedef LPDIRECT3DSURFACE9		PDSF;
typedef LPD3DXRENDERTOSURFACE	PDRS;



class CEftScn
{
public:
	struct VtxwDUV
	{
		D3DXVECTOR4	p;
		DWORD		d;
		D3DXVECTOR2	uv;

		VtxwDUV() : p(0,0,0,1.f), uv(0, 0), d(0xFFFFFFFF){}
		VtxwDUV(FLOAT X,FLOAT Y,FLOAT Z,FLOAT U,FLOAT V,DWORD D=0xFFFFFFFF) : p(X,Y,Z,1.f), uv(U, V), d(D){}

		enum {FVF=(D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)};
	};

	struct  EftRpl
	{
		D3DXVECTOR2	d;
		INT			r;					// WaterDistance from origin, in pixels 

		D3DXVECTOR2	p;					// initial vertex location 
		D3DXVECTOR2	c;					// texture coordinate 
		D3DXVECTOR2	t;					// default texture coordinate 
	};

protected:
	PDEV		m_pDev	;
	INT			m_nScnW	;
	INT			m_nScnH	;

	BOOL		m_bRn	;
	DWORD		m_dwI	;			// Initial time
	PDTX		m_pTxScn; 

	INT*		m_piX	;
	INT*		m_piY	;
	INT*		m_piT	;
	INT*		m_piM	;	
	FLOAT*		m_pfA	;			// Ampplitude
	VtxwDUV*	m_pVtx	;
	EftRpl**	m_pRpl	;			// Ripple
	
	INT			m_iM	;			// ripple_max;
	INT			m_iW	;			// Rendering Width
	INT			m_iH	;			// Rendering Height
	INT			m_iNX	;			// Grid Num X
	INT			m_iNY	;			// Grid Num Y
	INT			m_iL	;			// Ripple Length
	INT			m_iC	;			// Ripple Cycles
	FLOAT		m_fA	;			// Ripple Amplitude
	FLOAT		m_fS	;			// Ripple Step
	INT			m_iN	;			// Ripple Count
	
	
public:
	CEftScn();
	virtual ~CEftScn();
	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	void	Destroy();
	INT		FrameMove();
	void	Render();

	BOOL	IsActive()	{	return m_bRn;	}
	void	Reset(FLOAT X, FLOAT Y, float fAvgDeltaTime);
	void	SetTexture(PDTX	pTx);

protected:
	void	Drop(INT nPosX, INT nPosY);
	void	Dynamics();
	FLOAT	Distance(INT x0, INT y0, INT x1, INT y1);
	INT		DistanceMax(INT x, INT y);
	void	VertexCal();
	void	VectorCal();
	void	AmpCal();
};

#endif


