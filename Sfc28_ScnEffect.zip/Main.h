#ifndef _MAIN_H_
#define _MAIN_H_



class CMain : public CD3DApplication
{
public:
	ID3DXFont*	m_pD3DXFont;														// D3DX font
	TCHAR		m_sMsg[512];

	CMcInput*	m_pInput;
	CMcCam*		m_pCam;
	CMcGrid*	m_pGrid;

	IrenderTarget*	m_pRtc	;


	CMcField*		m_pField;
	INT				m_TreeNum;
	CMcMesh*		m_TreeMsh;
	D3DXMATRIX*		m_TreeMat;
	CMcMesh*		m_SkyBox;


	CEftScn*		m_pEft;															// Effect instance



public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT Render();
	virtual HRESULT FrameMove();

	void	RenderScene();
	
	
public:
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	CMain();	
};


extern CMain*	g_pApp;


#endif