// Interface for the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _EfSurface_H_
#define _EfSurface_H_


typedef D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;

typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPD3DXSPRITE						PDSP;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef LPDIRECT3DSURFACE9					PDSF;


class CEfSurface
{
public:
	struct VtxwUV1
	{
		VEC4	p;
		FLOAT	u,v;

		VtxwUV1(){}
		VtxwUV1(FLOAT X,FLOAT Y,FLOAT Z
				, FLOAT U,FLOAT V) : p(X,Y,Z,1.F),u(U),v(V){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_TEX1)};
	};


protected:
	PDEV		m_pDev;
	PDSP		m_pSpt;

	PDSF		m_pDevT;		// Device Color Buffer
	PDSF		m_pDevD;		// Device Depth Buffer

	VtxwUV1*	m_pVBGrd;
	WORD*		m_pIbGrd;

	PDTX		m_pTxOrg;
	
	PDTX		m_pTxSrc;
	PDSF		m_pSfSrc;

	PDTX		m_pTxDst;
	PDSF		m_pSfDst;
	
	
	INT			m_iNGrd;
	INT			m_iImgW;
	INT			m_iImgH;



public:
	CEfSurface();
	virtual ~CEfSurface();

	INT		Create(PDEV pDev, PDSP pSpt);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

protected:
	INT		RandomNumber(INT iMin, INT iMax);
};

#endif

