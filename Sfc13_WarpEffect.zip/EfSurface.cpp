// Implementation of the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CEfSurface::CEfSurface()
{
	m_pDev		= NULL;
	m_pSpt		= NULL;

	m_pDevT		= NULL;
	m_pDevD		= NULL;

	m_pVBGrd	= NULL;
	m_pIbGrd	= NULL;

	m_pTxOrg	= NULL;

	m_pTxDst	= NULL;
	m_pTxSrc	= NULL;

	m_pSfDst	= NULL;
	m_pSfSrc	= NULL;
}


CEfSurface::~CEfSurface()
{
	Destroy();
}


INT CEfSurface::Create(PDEV pDev, PDSP pSpt)
{
	m_pDev	= pDev;
	m_pSpt	= pSpt;

	//ȭ�� ũ�� ���

	IDirect3DSurface9*	pBackSurface=NULL;
	D3DSURFACE_DESC		dsc;

	if(FAILED(m_pDev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackSurface)))
		return-1;
		
	pBackSurface->GetDesc( &dsc );
	pBackSurface->Release();

	m_iImgW = dsc.Width;
	m_iImgH = dsc.Height;

	INT		i, j, k;
	
	m_iNGrd	= 50;

	
	// create grid vertex buffer
	m_pVBGrd = new VtxwUV1[m_iNGrd * m_iNGrd];
	m_pIbGrd = new WORD[ m_iNGrd * m_iNGrd * 2 * 3];

	for (j=0; j<m_iNGrd; ++j)
	{
		for (i=0; i<m_iNGrd; ++i)
		{
			FLOAT	x=0.f;
			FLOAT	y=0.f;
			FLOAT	z=0.5f;

			x	= i*2.f/(m_iNGrd-1.f)-1.0f;
			y	= (m_iNGrd-1.f-j)*2.f/(m_iNGrd-1.f) -1.f;
			z	= 0.f;

			x	= i * m_iImgW/(m_iNGrd-1.f);
			y	= j * m_iImgH/(m_iNGrd-1.f);
			z	= 0.5f;

			m_pVBGrd[ j*m_iNGrd +i ].p.x = x;
			m_pVBGrd[ j*m_iNGrd +i ].p.y = y;
			m_pVBGrd[ j*m_iNGrd +i ].p.z = z;

			m_pVBGrd[ j*m_iNGrd +i ].u = i/(m_iNGrd-1.f);
			m_pVBGrd[ j*m_iNGrd +i ].v = j/(m_iNGrd-1.f);
		}
	}


	k=0;

	for (j=0; j<m_iNGrd-1; ++j)
	{
		for (i=0; i<m_iNGrd-1; ++i)
		{
			m_pIbGrd[k++] = ((j+0)*m_iNGrd) + i+0;
			m_pIbGrd[k++] = ((j+0)*m_iNGrd) + i+1;
			m_pIbGrd[k++] = ((j+1)*m_iNGrd) + i+0;

			m_pIbGrd[k++] = ((j+1)*m_iNGrd) + i+1;
			m_pIbGrd[k++] = ((j+1)*m_iNGrd) + i+0;
			m_pIbGrd[k++] = ((j+0)*m_iNGrd) + i+1;
		}
	}



	if(FAILED(LcUtil_TextureLoad(m_pDev
								, "Texture/snow.png"
								, m_pTxOrg
								, 0x00FFFFFF
								, NULL
								, D3DX_FILTER_NONE
								, D3DX_FILTER_NONE
								, D3DFMT_UNKNOWN)))
		return -1;

	
	return 0;
}

void CEfSurface::Destroy()
{
	SAFE_RELEASE(	m_pTxOrg	);

	SAFE_DELETE_ARRAY(	m_pVBGrd	);
	SAFE_DELETE_ARRAY(	m_pIbGrd	);
}



INT CEfSurface::Restore()
{
	HRESULT hr=-1;

	// 1. Device�� Ÿ��, ���̽��ٽ� ������ �����͸� ���� �´�.
	m_pDev->GetRenderTarget(0, &m_pDevT);
	m_pDev->GetDepthStencilSurface(&m_pDevD);
	

	// 2. ȭ�� ����� �ؽ�ó�� �����Ѵ�.
	if(FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iImgW
									, m_iImgH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_A8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pTxSrc)))
		return -1;


	if(FAILED(hr = D3DXCreateTexture(m_pDev
									, m_iImgW
									, m_iImgH
									, 1
									, D3DUSAGE_RENDERTARGET
									, D3DFMT_A8R8G8B8
									, D3DPOOL_DEFAULT
									, &m_pTxDst)))
		return -1;

	

	// 3. �ؽ�ó�� ���ǽ��� ��� �´�.
	m_pTxSrc->GetSurfaceLevel(0, &m_pSfSrc);
	m_pTxDst->GetSurfaceLevel(0, &m_pSfDst);

	
	
	m_pDev->SetRenderTarget(0, m_pSfSrc);

	m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00FFFFFF, 1.0f, 0L );

	m_pDev->BeginScene();

	RECT	rc={0,0, m_iImgW, m_iImgH};
	m_pSpt->Begin(D3DXSPRITE_ALPHABLEND);
	m_pSpt->Draw(m_pTxOrg, &rc, NULL, NULL, D3DXCOLOR(1,1,1, 1.F));
	m_pSpt->End();
	
	m_pDev->EndScene();

	hr=m_pDev->SetRenderTarget(0, m_pDevT);
	hr=m_pDev->SetDepthStencilSurface(m_pDevD);

	return 0;
}


void CEfSurface::Invalidate()
{
	SAFE_RELEASE(	m_pDevT		);
	SAFE_RELEASE(	m_pDevD		);

	SAFE_RELEASE(	m_pSfDst	);
	SAFE_RELEASE(	m_pSfSrc	);

	SAFE_RELEASE(	m_pTxSrc	);
	SAFE_RELEASE(	m_pTxDst	);
}


INT CEfSurface::FrameMove()
{
	HRESULT	hr=0;

	static DWORD	dBgn = ::GetTickCount();
	DWORD			dCur = ::GetTickCount();

	if(dCur < dBgn+20)
		return 0;

	dBgn = dCur;

	INT	i, j;

	for(j=0; j<m_iNGrd; ++j)
	{
		for(i=0; i<m_iNGrd; ++i)
		{
			m_pVBGrd[j*m_iNGrd +i].u = i/(m_iNGrd-1.f);
			m_pVBGrd[j*m_iNGrd +i].v = j/(m_iNGrd-1.f);

			m_pVBGrd[j*m_iNGrd +i].u += RandomNumber(-100, 100) * 0.0001;
			m_pVBGrd[j*m_iNGrd +i].v += RandomNumber(-100, 100) * 0.0001;
		}
	}



	m_pDev->SetRenderTarget(0, m_pSfDst);


	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_POINT);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	
	m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00FFFFFF, 1.0f, 0L );

	m_pDev->SetTexture( 0, m_pTxSrc);
	m_pDev->SetFVF( VtxwUV1::FVF);

	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0
									, m_iNGrd*m_iNGrd
									, (m_iNGrd-1)*(m_iNGrd-1)*2
									, m_pIbGrd, D3DFMT_INDEX16
									, m_pVBGrd, sizeof(VtxwUV1) );

	
	// ������ Ÿ�ϰ� ���� ���۸� �� ������ ����̽�
	// ���� ���ۿ� ����̽� ���۷� �ٲ۴�.
	m_pDev->SetRenderTarget(0, m_pDevT);
	m_pDev->SetDepthStencilSurface(m_pDevD);


	// Surface�� Texture�� ��ü
	PDTX pTxTmp	= NULL;
	pTxTmp		= m_pTxDst;
	m_pTxDst	= m_pTxSrc;
	m_pTxSrc	= pTxTmp;

	PDSF pSfTmp	= NULL;
	pSfTmp		= m_pSfDst;
	m_pSfDst	= m_pSfSrc;
	m_pSfSrc	= pSfTmp;


	return 0;
}


void CEfSurface::Render()
{
	RECT	rc={0,0, m_iImgW, m_iImgH};
	m_pSpt->Begin(D3DXSPRITE_ALPHABLEND);
	m_pSpt->Draw(m_pTxDst, &rc, NULL, NULL, D3DXCOLOR(1,1,1, 1.F));
	m_pSpt->End();
}


INT CEfSurface::RandomNumber(INT iMin, INT iMax)
{
	if (iMin == iMax)
		return(iMin);

	return((rand() % (abs(iMax-iMin)+1))+iMin);
}