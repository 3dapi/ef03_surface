// Interface for the CMcTree class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCTREE_H_
#define _MCTREE_H_


struct McImage
{
	PDTX	pTx;
	DIMG	Img;
};

struct McBill
{
	INT		nT;			// Texture Index;
	VEC3	vcP;		// Position
	FLOAT	fZ;			// z ���⿡ ���� ī�޶���� �Ÿ�
};

class CMcTree  
{
protected:
	McImage		m_pTxTree[3];
	
	INT			m_iN;
	McBill*		m_pBill;
	VtxDUV1*	m_pVtx;
	
public:
	CMcTree();
	~CMcTree();
	
	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();
	
	static int SortFnc (McBill* p1, const McBill* p2)
	{
		INT	score1, score2;

		score1 = p1->fZ;
		score2 = p2->fZ;

		if(score1 < score2)
			return 1;

		else if(score1 == score2)
			return 0;

		else 
			return -1;
	}
};

#endif