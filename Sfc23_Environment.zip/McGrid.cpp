// Implementation of the CMcGrid class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcGrid::CMcGrid()
:	m_pLine		(0)
{
}

CMcGrid::~CMcGrid()
{
	Destroy();
}


INT CMcGrid::Init()
{
	INT		i;
	INT		j;
	FLOAT	fMax;

	fMax = 10000;
	m_pLine = new VtxD[ (6 + 8*4 ) * 2 ];

	m_pLine[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pLine[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pLine[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pLine[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	j =6 * 2;

	for(i=0; i<8; ++i)
	{
		m_pLine[j + 8*i +0 ] = VtxD(-128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +1 ] = VtxD( 128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +2 ] = VtxD(-128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +3 ] = VtxD( 128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);

		m_pLine[j + 8*i +4 ] = VtxD( 16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +5 ] = VtxD( 16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +6 ] = VtxD(-16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +7 ] = VtxD(-16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
	}
	
	return 1;
}


void CMcGrid::Destroy()
{
	SAFE_DELETE_ARRAY(		m_pLine		);
}


INT	CMcGrid::FrameMove()
{
	
	return 1;
}

void CMcGrid::Render()
{
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(VtxD::FVF);

	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 32, m_pLine, sizeof(VtxD));
}