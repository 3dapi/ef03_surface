// Interface for the CMcCamera class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_

class CMcCamera
{
protected:
	D3DXMATRIX	m_mtViw;													// View Matrix
	D3DXMATRIX	m_mtPrj;													// Projection Matrix

	D3DXVECTOR3		m_vcEye;													// Camera position
	D3DXVECTOR3		m_vcLook;													// Look vector
	D3DXVECTOR3		m_vcUp;														// up vector

	FLOAT			m_fYaw;
	FLOAT			m_fPitch;
	
public:
	void Transform();
	CMcCamera();
	~CMcCamera();

	INT		Init();
	INT		FrameMove();

	D3DXMATRIX	GetViewMatrix()	{	return m_mtViw;	}
	VEC3		GetPos()		{	return m_vcEye;	}

	VEC3		GetAxisZ()		{	return VEC3(m_mtViw._13, m_mtViw._23, m_mtViw._33);	}

protected:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
};

#endif
