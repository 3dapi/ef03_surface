#include "_StdAfx.h"


void McUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}


void McUtil_SetWindowTitle(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	// �̷��� ���������� �ʿ��� ���̴�.
	SetWindowText(GHWND, s);
}



// Texture Load
INT	 McUtil_TextureLoad(TCHAR * sFile, PDTX& pTx, DWORD color, D3DXIMAGE_INFO *pSrcInfo, DWORD Filter, DWORD MipFilter, D3DFORMAT d3dFormat)
{
	if ( FAILED(D3DXCreateTextureFromFileEx(
		GDEVICE
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, color
		, pSrcInfo
		, NULL
		, &pTx
		)) )
	{
		pTx = NULL;
		return -1;
	}
	
	return 1;
}



void McUtil_VBCreate(PDVB& pVB, int nSize, DWORD fvf, void* pVtx, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateVertexBuffer(nSize,
		0,
		fvf,
		usage,
		&pVB, NULL );
	
	if( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Vertex create failed");
		return ;
	}
	
	if(!pVtx)
		return;

	McUtil_VBLock(pVB, nSize, pVtx);
}


void McUtil_VBLock(PDVB& pVB, int nSize, void* pVtx)
{
	void* p;
	
	if( FAILED( pVB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy( p, pVtx, nSize);
	pVB->Unlock();
}


void McUtil_IBCreate(PDIB& pIB, int nSize, void* pIdx, D3DFORMAT fmt, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateIndexBuffer( nSize, 0, fmt, usage, &pIB, NULL);
	
	if( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Index buffer create failed");
		return ;
	}
	
	if(!pIdx)
		return;

	McUtil_IBLock(pIB, nSize, pIdx);
}


void McUtil_IBLock(PDIB & pIB, int nSize, void* pIdx)
{
	void* p;
	
	if( FAILED( pIB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy(p, pIdx, nSize);
	pIB->Unlock();
}


void McUtil_TransformIdentity(D3DTRANSFORMSTATETYPE nType)
{
	static MATA mtI(1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1);

	GDEVICE->SetTransform(nType, &mtI);
}