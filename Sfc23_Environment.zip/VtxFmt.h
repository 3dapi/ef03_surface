#ifndef _VTXFMT_H_
#define _VTXFMT_H_



struct VtxD
{
	VEC3	p;
	DWORD	d;
	
	VtxD()	{}
	VtxD(FLOAT X,FLOAT Y,FLOAT Z, DWORD D=0xFFFFFFFF):p(X,Y,Z),d(D){}
	enum	{FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
};


struct VtxDUV1
{
	VEC3	p;
	DWORD	d;
	FLOAT	u,v;
	

	VtxDUV1()	{}
	VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
		,FLOAT U,FLOAT V
		, DWORD D=0xFFFFFFFF):p(X,Y,Z)
			,u(U),v(V)
			,d(D){}
	enum	{FVF = ((D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)),};
};



struct VtxN
{
	VEC3	p;
	VEC3	n;

	VtxN()	{}
	VtxN(FLOAT X,FLOAT Y,FLOAT Z
		,FLOAT nX,FLOAT nY,FLOAT nZ):p(X,Y,Z),n(nX,nY,nZ){}
	enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL),};
};



struct VtxNDUV2
{
	VEC3	p;
	VEC3	n;
	DWORD	d;
	FLOAT	u0,v0;
	FLOAT	u1,v1;

	VtxNDUV2()	{}
	VtxNDUV2(FLOAT X,FLOAT Y,FLOAT Z,FLOAT nX,FLOAT nY,FLOAT nZ
		,FLOAT U0,FLOAT V0,FLOAT U1,FLOAT V1
		, DWORD D=0xFFFFFFFF):p(X,Y,Z),n(nX,nY,nZ)
		,u0(U0),v0(V0)
		,u1(U1),v1(V1)
		, d(D){}
	enum	{FVF = ((D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX2)),};
};




struct VtxIdx
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	VtxIdx()							{	a = 0;	  b = 1;		 c = 2;	}
	VtxIdx(WORD A, WORD B, WORD C)		{	a = A;    b = B;		 c = C;	}
	VtxIdx(WORD* R)						{	a = R[0]; b = R[1];	 c = R[2];	}
	operator WORD* ()					{		return (WORD *) &a;			}
	operator CONST WORD* () const		{		return (CONST WORD *) &a;	}
};

#endif _VTXFMT_H_