// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	m_pTx0	= NULL;
	m_pTx1	= NULL;
	m_iNvx	= 0;
	m_iNix	= 0;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Init()
{
	m_fAl = 45;
	m_iW = 32;
	m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	
	//	Load texture
	McUtil_TextureLoad("Texture/detail5.jpg", m_pTx0, 0x00000000);

	ZeroMemory( &m_light, sizeof(m_light) );
	m_light.Type = D3DLIGHT_DIRECTIONAL;
	m_light.Diffuse = D3DXCOLOR( 1.F, 1.F, 1.F, 1.F);
	m_light.Specular= D3DXCOLOR( 0.F, 0.F, .5F, .5F);
	m_light.Ambient= D3DXCOLOR( 0.4F, 0.4F, .4F, .4F);

	D3DUtil_InitMaterial( m_mtl, 1.0f, 1.0f, 1.0f );


	MapLoad();

	MapTex();																	// Diffuse Map�� �����Ѵ�.
	
	return 1;
}


void CMcField::Destroy()
{
	
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pIdx	);
	
	SAFE_RELEASE(	m_pTx0	);
	SAFE_RELEASE(	m_pTx1	);
}


INT	CMcField::FrameMove()
{
	if( GINPUT->KeyState(DIK_LEFT))
	{
		++m_fAl;
		m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	}
	
	if( GINPUT->KeyState(DIK_RIGHT))
	{
		--m_fAl;
		m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	}
	
	return 1;
}

void CMcField::Render()
{
	McUtil_TransformIdentity(D3DTS_WORLD);
	
	m_light.Direction = m_vcLgt;
			
	GDEVICE->SetLight( 0, &m_light );
	GDEVICE->LightEnable( 0, TRUE );
	
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  TRUE);
	GDEVICE->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );

	GDEVICE->SetMaterial( &m_mtl );
	


	DWORD dFog = D3DXCOLOR(.5f, .5f, .5f, 1.0f);

	dFog = 0xFF006699;
	float fStart = 300.0f;
	float fEnd   = 4500.0f;

	GDEVICE->SetRenderState(D3DRS_FOGENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
	GDEVICE->SetRenderState(D3DRS_FOGCOLOR, dFog);
	GDEVICE->SetRenderState(D3DRS_FOGSTART, FtoDW(fStart));
	GDEVICE->SetRenderState(D3DRS_FOGEND,   FtoDW(fEnd));

	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	GDEVICE->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(1, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );

	GDEVICE->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 1, D3DTSS_COLORARG2, D3DTA_CURRENT );
	GDEVICE->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );

	GDEVICE->SetTexture(0, m_pTx0);
	GDEVICE->SetTexture(1, m_pTx1);
	GDEVICE->SetFVF(m_dFVF);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNvx, m_iNix, m_pIdx, D3DFMT_INDEX16, m_pVtx, m_iVxS);
	
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetTexture(1, 0);
}




FLOAT CMcField::GetHeight(VEC3& pos)
{
	INT	x;
	INT	z;

	x = INT(pos.x/m_iW);
	z = INT(pos.z/m_iW);

	INT index = m_iN*z + x;

	VEC3 pos0 = m_pVtx[index].p;
	VEC3 posX;
	VEC3 posZ;
	VEC3 posT;


	float dX = pos.x - pos0.x;
	float dZ = pos.z - pos0.z;

	if( (x+z)%2)			// Ȧ��
	{
		if(dZ >(m_iW-dX))			// ���� �ﰢ��
		{
			index += (m_iN+1);

			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index-1].p;
			posZ = m_pVtx[index-m_iN].p;
		}

		else
		{
			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index+1].p;
			posZ = m_pVtx[index+m_iN].p;
		}
	}
	else					// ¦��
	{
		if(dZ > dX)			// ���� �ﰢ��
		{
			index += (m_iN);

			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index+1].p;
			posZ = m_pVtx[index-m_iN].p;
		}

		else
		{
			index += 1;

			pos0 = m_pVtx[index].p;
			posX = m_pVtx[index-1].p;
			posZ = m_pVtx[index+m_iN].p;
		}
	}

	posT  = pos0 + (posX - pos0) * dX/m_iW + (posZ - pos0) * dZ/m_iW;


	return posT.y;
}


void CMcField::NormalSet()
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	
	for(INT z=0; z<m_iN; ++z)
	{
		for(INT x=0; x<m_iN; ++x)
		{
			m_pVtx[m_iN*z + x].n = -NormalVec(z, x);
		}
	}
}


VEC3 CMcField::NormalVec(int z, int x)
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	INT		i;

	INT		index = m_iN*z + x;
	INT		iVtx[10];

	iVtx[9] = index;
	iVtx[0] = iVtx[9];
	iVtx[1] = iVtx[9];
	iVtx[2] = iVtx[9];
	iVtx[3] = iVtx[9];
	iVtx[4] = iVtx[9];
	iVtx[5] = iVtx[9];
	iVtx[6] = iVtx[9];
	iVtx[7] = iVtx[9];
	iVtx[8] = iVtx[9];
	
	if(0==z && 0==x)
	{
		iVtx[0] = iVtx[9] + 1;
		iVtx[1] = iVtx[0] + m_iN;
		iVtx[2] = iVtx[9] + m_iN;
	}

	else if(0==z && (m_iN-1) == x)
	{
		iVtx[0] = iVtx[9] + m_iN;
		iVtx[1] = iVtx[0] - 1;
		iVtx[2] = iVtx[9] - 1;
	}

	else if(0==z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iN;
			iVtx[2] = iVtx[9] - 1;			
		}
		else
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iN;
			iVtx[2] = iVtx[9] + m_iN;
			iVtx[3] = iVtx[2] - 1;
			iVtx[4] = iVtx[9] - 1;
		}
	}
	
	else if( (m_iN-1) == z && 0==x)
	{
		iVtx[0] = iVtx[9] - m_iN;
		iVtx[1] = iVtx[0] + 1;
		iVtx[2] = iVtx[9] + 1;
	}

	else if( (m_iN-1) == z && (m_iN-1) == x)
	{
		iVtx[0] = iVtx[9] - 1;
		iVtx[1] = iVtx[0] - m_iN;
		iVtx[2] = iVtx[9] - m_iN;

	}

	else if((m_iN-1) == z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iN;
			iVtx[2] = iVtx[9] + 1;
		}
		else
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[0] - m_iN;
			iVtx[2] = iVtx[9] - m_iN;
			iVtx[3] = iVtx[2] + 1;
			iVtx[4] = iVtx[9] + 1;
		}
	}

	else if(0 == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - m_iN;
			iVtx[1] = iVtx[9] + 1;
			iVtx[2] = iVtx[9] + m_iN;
		}
		else
		{
			iVtx[0] = iVtx[9] - m_iN;
			iVtx[1] = iVtx[0] + 1;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[2] + m_iN;
			iVtx[4] = iVtx[9] + m_iN;
		}
	}

	else if((m_iN-1) == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + m_iN;
			iVtx[1] = iVtx[9] - 1;
			iVtx[2] = iVtx[9] - m_iN;
		}
		else
		{
			iVtx[0] = iVtx[9] + m_iN;
			iVtx[1] = iVtx[0] - 1;
			iVtx[2] = iVtx[9] - 1;
			iVtx[3] = iVtx[2] - m_iN;
			iVtx[4] = iVtx[9] - m_iN;
		}
	}
	

	else
	{
		if(index%2)																// Ȧ ��
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iN;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[9] + m_iN;
			iVtx[4] = iVtx[0];
		}
		else																	// ¦ ��
		{

//			iVtx[6] = index +m_iN	-1;		iVtx[5] = index + m_iN;	iVtx[4] = index +m_iN	+1;
//			iVtx[7] = index			-1;		iVtx[9] = index		  ;	iVtx[3] = index			+1;
//			iVtx[0] = index -m_iN	-1;		iVtx[1] = index - m_iN;	iVtx[2] = index -m_iN	+1;

			iVtx[6] = index +m_iN	-1;		iVtx[5] = iVtx[6] + 1;	iVtx[4] = iVtx[5] + 1;
			iVtx[7] = index			-1;		iVtx[9] = iVtx[7] + 1;	iVtx[3] = iVtx[9] + 1;
			iVtx[0] = index -m_iN	-1;		iVtx[1] = iVtx[0] + 1;	iVtx[2] = iVtx[1] + 1;
			iVtx[8] = iVtx[0];
		}
	}

	for(i=0; i<8; ++i)
	{
		a = m_pVtx[iVtx[i+0] ].p - m_pVtx[iVtx[9] ].p;
		b = m_pVtx[iVtx[i+1] ].p - m_pVtx[iVtx[9] ].p;
		D3DXVec3Cross(&nT, &a, &b);
		D3DXVec3Normalize(&nT, &nT);
		n +=nT;
	}

	
	D3DXVec3Normalize(&n, &n);
	
	return n;
}



void CMcField::MapLoad()
{
	FILE* fp;
	
	INT x, z;
	TCHAR sFile[] = "Map/Height.raw";

	
	fp = fopen(sFile, "rb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Height file load failed");
		return;
	}
	
	long end;
	
	fseek(fp, 0L, SEEK_SET);	fseek (fp, 0L, SEEK_END);	end	   = ftell(fp);
	fseek(fp, 0L, SEEK_SET);
	
	BYTE*	pHi = new BYTE[end];
	fread(pHi, sizeof(BYTE), end, fp);
	fclose(fp);
	
	
	m_dFVF = VtxNDUV2::FVF;
	m_iVxS = sizeof(VtxNDUV2);
	m_iNvx = end;
	m_iN = int(sqrtf( FLOAT(m_iNvx)));
	m_pVtx = new VtxNDUV2[m_iNvx];
	
	for(z=0; z<m_iN; ++z)
	{
		for(x=0; x<m_iN; ++x)
		{
			FLOAT fH = pHi[ (m_iN-1-z) * m_iN + x]*2.5f;
			m_pVtx[z * m_iN +x ].p = VEC3(FLOAT(x * m_iW), fH, FLOAT(z * m_iW));

//			m_pVtx[z * m_iN +x ].p.x -= m_iN/2.f * m_iW;
//			m_pVtx[z * m_iN +x ].p.z -= m_iN/2.f * m_iW;
		}
	}
	
	SAFE_DELETE_ARRAY(	pHi	);
	
	
	for(z=0; z<m_iN; ++z)														// ������ UV�� ä���.
	{
		for(x=0; x<m_iN; ++x)
		{
			m_pVtx[z * m_iN +x ].u0 = x /2.f;
			m_pVtx[z * m_iN +x ].v0 = z /2.f;

			m_pVtx[z * m_iN +x ].u1 = x /FLOAT(m_iN-1);
			m_pVtx[z * m_iN +x ].v1 = z /FLOAT(m_iN-1);

		}
	}
	

	NormalSet();																// ���� ���͸� ä���.


	
	INT iN = m_iN-1;
	
	m_iNix = 8 * (m_iN-1)/2 * (m_iN-1)/2;
	
	m_pIdx = new VtxIdx[m_iNix];
	
	INT i=0;
	
	WORD index;
	WORD f[9];
	
	for(z=0; z< iN/2;++z)														// Index�� ä���.
	{
		for(x=0;x<iN/2;++x)
		{
			index = 2*m_iN*z + m_iN+1 + 2*x;
			
			f[6] = index +m_iN-1;	f[5] = index + m_iN;	f[4] = index +m_iN+1;
			f[7] = index      -1;	f[8] = index	   ;	f[3] = index      +1;
			f[0] = index -m_iN-1;	f[1] = index - m_iN;	f[2] = index -m_iN+1;
			
			
			i = z * iN/2 + x;
			i *=8;
			
			for(int m=0; m<8; ++m)
				m_pIdx[i+m] = VtxIdx( f[8], f[(m+1)%8], f[(m+0)%8]);
		}
	}	
}




D3DXCOLOR	g_TableColor[] =
{
	D3DXCOLOR(255/255.f, 249/255.f, 157/255.f, 1.f),
	D3DXCOLOR(124/255.f, 197/255.f, 118/255.f, 1.f),
	D3DXCOLOR(  0/255.f, 166/255.f,  81/255.f, 1.f),
	D3DXCOLOR( 25/255.f, 123/255.f,  48/255.f, 1.f),
	D3DXCOLOR(115/255.f, 100/255.f,  87/255.f, 1.f),
	D3DXCOLOR(255/255.f, 255/255.f, 255/255.f, 1.f),
};


void CMcField::MapTex()
{
	D3DXCreateTexture( GDEVICE, m_iN-1, m_iN-1, 0, 0, D3DFMT_X8R8G8B8, D3DPOOL_MANAGED, &m_pTx1);
	
	D3DSURFACE_DESC Dsc;
	LPDIRECT3DSURFACE9	pSf=NULL;
	D3DLOCKED_RECT lockedRect;


	m_pTx1->GetLevelDesc(0, &Dsc);
	m_pTx1->GetSurfaceLevel(0, &pSf);
	pSf->LockRect(&lockedRect, 0 , 0);
	
	DWORD* imageData = (DWORD*)lockedRect.pBits;

	memset(imageData, 0, sizeof(DWORD) * Dsc.Width * Dsc.Height);

	for(int z = 0; z<m_iN-1; ++z)
	{
		for(int x = 0; x<m_iN-1; ++x)
		{
			D3DXCOLOR c;
	
			float	height = m_pVtx[z*m_iN + x].p.y /4.5f;
			float	fWeight;
			
			if( (height) < 1.f )
			{
				fWeight =1.f;
				c = fWeight * g_TableColor[0];
			}
			else if( (height) < 35.0f )
			{
				fWeight = (height-1.f)/(35.f-1.f) * 1.2f;

				if(fWeight>1)
					fWeight = 1.f;

				c = fWeight * g_TableColor[1] + (1-fWeight) * g_TableColor[0];
			}
			else if( (height) < 75.5f )
			{
				fWeight = (height-35.0f)/(75.5f-35.0f) * 1.2f;

				if(fWeight>1)
					fWeight = 1.f;

				c = fWeight * g_TableColor[2] + (1-fWeight) * g_TableColor[1];
			}
			else if( (height) < 100.0f )
			{
				fWeight = (height-75.5f)/(100.f-75.5f) * 1.2f;

				if(fWeight>1)
					fWeight = 1.f;

				c = fWeight * g_TableColor[3] + (1-fWeight) * g_TableColor[2];
			}
			else if( (height) < 140.5f )
			{
				fWeight = (height-100.0f)/(140.5f-100.f) * 1.2f;

				if(fWeight>1)
					fWeight = 1.f;

				c = fWeight * g_TableColor[4] + (1-fWeight) * g_TableColor[3];
			}
			else
			{
				fWeight = (height-140.0f)/60.F * 1.2f;

				if(fWeight>1)
					fWeight = 1.f;
				
				c = fWeight * g_TableColor[5] + (1-fWeight) * g_TableColor[4];
			}
			
			imageData[z * Dsc.Width + x] = c;
		}
	}

	pSf->UnlockRect();

	SAFE_RELEASE(	pSf		);
}