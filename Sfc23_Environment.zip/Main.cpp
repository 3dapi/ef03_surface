// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCam			= NULL;

	m_pGrid			= NULL;
	m_pField		= NULL;

	m_pTree			= NULL;
	m_pEnv			= NULL;
}


HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = FALSE;
	
	return S_OK;
}


HRESULT CMain::Init()
{
	SAFE_NEWINIT(	m_pInput,	CMcInput	);
	SAFE_NEWINIT(	m_pCam	,	CMcCamera	);

	SAFE_NEWINIT(	m_pGrid	,	CMcGrid		);
	SAFE_NEWINIT(	m_pField,	CMcField	);
	SAFE_NEWINIT(	m_pTree	,	CMcTree		);

	SAFE_NEWINIT(	m_pEnv	,	CEnvSphere	);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);

	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pField	);
	SAFE_DELETE(	m_pTree		);

	SAFE_DELETE(	m_pEnv		);

	return S_OK;
}


HRESULT CMain::Restore()
{
	D3DXFONT_DESC hFont = { 16, 0, FW_NORMAL, 1, 0,
		HANGUL_CHARSET, OUT_DEFAULT_PRECIS,	ANTIALIASED_QUALITY
		, FF_DONTCARE, "Arial"};

	if( FAILED( D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;

	


	SAFE_RESTORE(	m_pEnv	);
	return S_OK;
}



HRESULT CMain::Invalidate()
{
	SAFE_RELEASE( m_pD3DXFont );

	SAFE_INVALIDATE(	m_pEnv	);
	
	return S_OK;
}



HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCam		);

	SAFE_FRAMEMOVE(	m_pGrid		);
	SAFE_FRAMEMOVE(	m_pField	);
	SAFE_FRAMEMOVE(	m_pTree		);

	SAFE_FRAMEMOVE(	m_pEnv		);

	return S_OK;
}




HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x00006699, 1.0f, 0L);
	
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	SAFE_RENDER(	m_pGrid		);
	SAFE_RENDER(	m_pField	);
	SAFE_RENDER(	m_pTree		);

	SAFE_RENDER(	m_pEnv		);
	
	RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}





// Name: RenderText()
// Desc: Renders stats and help text to the scene.

HRESULT CMain::RenderText()
{
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetTexture( 0, 0);

	D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH] = TEXT("");
	RECT rct;
	ZeroMemory( &rct, sizeof(rct) );       
	
	
	rct.left   = 2;
	rct.right  = m_d3dsdBackBuffer.Width - 20;
	
	// Output display stats
	INT nNextLine = 40; 
	
	lstrcpy( szMsg, m_strDeviceStats );
	nNextLine -= 20; rct.top = nNextLine; rct.bottom = rct.top + 20;    
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );
	
	lstrcpy( szMsg, m_strFrameStats );
	nNextLine -= 20; rct.top = nNextLine; rct.bottom = rct.top + 20;    
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );

	
	
	return S_OK;
}





// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).

LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				// Draw on the window tell the user that the app is loading
				// TODO: change as needed
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rct;
				GetClientRect( hWnd, &rct );
				DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}