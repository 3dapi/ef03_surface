// EnvSphere.cpp: implementation of the CEnvSphere class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


#define CUBEMAP_RESOLUTION 64


CEnvSphere::CEnvSphere()
{
	m_pRenderToEnvMap   = NULL;
	m_pCubeMap          = NULL;
	m_pSphereMap        = NULL;
	
	m_pVB				= NULL;
	m_pIB				= NULL;

	m_nType				= 1;			// Sphere Map
}

CEnvSphere::~CEnvSphere()
{
	Destroy();
}


INT CEnvSphere::Init()
{
	m_pShinyTeapot = new CD3DMesh();
	
	// Load the file objects
	if( FAILED( m_pShinyTeapot->Create( GDEVICE, _T("Model/tiger.x") ) ) )
		return -1;
	
	m_pShinyTeapot->SetFVF( GDEVICE, VtxN::FVF );
	
	return 0;
}


void CEnvSphere::Destroy()
{
	m_pShinyTeapot->Destroy();
	
	SAFE_RELEASE( m_pSphereMap );
	SAFE_DELETE( m_pShinyTeapot );
}



INT CEnvSphere::Restore()
{
	m_pShinyTeapot->RestoreDeviceObjects( GDEVICE );
	m_iNvx = m_pShinyTeapot->m_pLocalMesh->GetNumVertices();
	m_iNix = m_pShinyTeapot->m_pLocalMesh->GetNumFaces();
	
	m_pShinyTeapot->m_pLocalMesh->GetVertexBuffer(&m_pVB);
	m_pShinyTeapot->m_pLocalMesh->GetIndexBuffer(&m_pIB);
	
	VtxN* pVtx;
	
	m_pVB->Lock(0,0,(void**)&pVtx, 0);
	
	for(DWORD i=0; i<m_iNvx; ++i)
	{
		pVtx[i].p *= 1.f;
	}
	
	m_pVB->Unlock();
	
	
	// Create RenderToEnvMap object
	if( FAILED( D3DXCreateRenderToEnvMap( GDEVICE, CUBEMAP_RESOLUTION, 1, GMAIN->m_d3dsdBackBuffer.Format, TRUE, D3DFMT_D24S8, &m_pRenderToEnvMap ) ) )
	{
		return E_FAIL;
	}


	// Create the cubemap, with a format that matches the backbuffer
	if(0 == m_nType)
	{
		if( GMAIN->m_d3dCaps.TextureCaps & D3DPTEXTURECAPS_CUBEMAP )
		{
			if( FAILED( D3DXCreateCubeTexture( GDEVICE, CUBEMAP_RESOLUTION, 1,
				D3DUSAGE_RENDERTARGET, GMAIN->m_d3dsdBackBuffer.Format, D3DPOOL_DEFAULT, &m_pCubeMap ) ) )
			{
				if( FAILED( D3DXCreateCubeTexture( GDEVICE, CUBEMAP_RESOLUTION, 1,
					0, GMAIN->m_d3dsdBackBuffer.Format, D3DPOOL_DEFAULT, &m_pCubeMap ) ) )
				{
					m_pCubeMap = NULL;
				}
			}
		}
	}

	else
	{
		// Create the spheremap, with a format that matches the backbuffer
		if( FAILED( D3DXCreateTexture( GDEVICE, CUBEMAP_RESOLUTION, CUBEMAP_RESOLUTION, 
			1, D3DUSAGE_RENDERTARGET, GMAIN->m_d3dsdBackBuffer.Format, D3DPOOL_DEFAULT, &m_pSphereMap ) ) )
		{
			if( FAILED( D3DXCreateTexture( GDEVICE, CUBEMAP_RESOLUTION, CUBEMAP_RESOLUTION, 
				1, 0, GMAIN->m_d3dsdBackBuffer.Format, D3DPOOL_DEFAULT, &m_pSphereMap ) ) )
			{
				return E_FAIL;
			}
		}
	}
	
	
	return 0;
}

void CEnvSphere::Invalidate()
{
	m_pShinyTeapot->InvalidateDeviceObjects();
	
	SAFE_RELEASE( m_pRenderToEnvMap );
	SAFE_RELEASE( m_pCubeMap );
	SAFE_RELEASE( m_pSphereMap );
	
	SAFE_RELEASE(m_pVB);
	SAFE_RELEASE(m_pIB);
}

INT CEnvSphere::FrameMove()
{
	VEC3 vcP = GCAM->GetPos();
	VEC3 vcZ = GCAM->GetAxisZ();

	vcP += vcZ* 5.f;

	GDEVICE->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	D3DXMatrixTranslation(&m_mtWld, vcP.x, vcP.y, vcP.z);
	RenderSceneIntoEnvMap();
	GCAM->Transform();
	GDEVICE->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
	
	return 0;
}


void CEnvSphere::Render()
{
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_MIRROR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_MIRROR );


	GDEVICE->SetTransform(D3DTS_WORLD, &m_mtWld);
	

	// Cube Mapping
	if(0 == m_nType)
	{
		GDEVICE->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR);
		GDEVICE->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT3);
		GDEVICE->SetTexture(0, m_pCubeMap);
	}
	else
	{
		D3DXMATRIX mat(
			0.5f,	0.f,	0.f,	0.f,
			0.f,	-0.5f,	0.f,	0.f,
			0.f,	0.f,	1.f,	0.f,
			0.5f,	0.5f,	0.f,	1.f	);
		
		GDEVICE->SetTransform(D3DTS_TEXTURE0, &mat);
		GDEVICE->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACENORMAL);
		GDEVICE->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
		GDEVICE->SetTexture(0, m_pSphereMap);
	}
	
	
	// Draw teapot
	GDEVICE->SetStreamSource(0, m_pVB, 0, sizeof(VtxN));
	GDEVICE->SetFVF(VtxN::FVF);
	GDEVICE->SetIndices( m_pIB );
	GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_iNvx, 0, m_iNix);



	// Default Setting
	GDEVICE->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_PASSTHRU);
	GDEVICE->SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_DISABLE);
	
	McUtil_TransformIdentity(D3DTS_TEXTURE0);
	McUtil_TransformIdentity(D3DTS_WORLD);


	// Show Envrionment Texture
	RECT rc= {0,0,CUBEMAP_RESOLUTION,CUBEMAP_RESOLUTION};
	//GSPRITE->Begin(D3DXSPRITE_ALPHABLEND);

	//if(1 == m_nType)
	//{
	//	D3DXVECTOR3	vcPos(0,50,0);
	//	GSPRITE->Draw(m_pSphereMap, &rc, NULL, &vcPos, D3DXCOLOR(1,1,1,1));
	//}

	//GSPRITE->End();
}


HRESULT CEnvSphere::RenderSceneIntoEnvMap()
{
	HRESULT hr;
	
	// ����� �ؽ�ó�� ������

	// 1. ���� ����� �����.
	D3DXMATRIX matProj;
	D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI * 0.5f, 1.0f, .1f, 5000.0f );

	
	// 2. ī�޶󿡼� ������� ���´�.
	D3DXMATRIX matViewDir( GCAM->GetViewMatrix());


	GDEVICE->SetRenderState( D3DRS_ZFUNC, D3DCMP_ALWAYS );
	GDEVICE->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );



	// 3. ����� �ؽ�ó�� �������Ѵ�.
	if(0 == m_nType)
		hr = m_pRenderToEnvMap->BeginCube( m_pCubeMap );
	else
		hr = m_pRenderToEnvMap->BeginSphere( m_pSphereMap);


	for( UINT i = 0; i < 6; i++ )
	{
		m_pRenderToEnvMap->Face( (D3DCUBEMAP_FACES) i, 0);
		
		// Set the view transform for this cubemap surface
		D3DXMATRIX matView;
		matView = D3DUtil_GetCubeMapViewMatrix( (D3DCUBEMAP_FACES) i );
		D3DXMatrixMultiply( &matView, &matViewDir, &matView );
		
		RenderScene( &matView, &matProj);
	}


	m_pRenderToEnvMap->End( 0 );
	return S_OK;
}





HRESULT CEnvSphere::RenderScene(D3DXMATRIX *pView, D3DXMATRIX *pProject)
{
	D3DXMATRIX matView(*pView);
//	matView._41 = matView._42 = matView._43 = 0.0f;
	
	GDEVICE->SetTransform( D3DTS_WORLD, &m_mtWld );
	GDEVICE->SetTransform( D3DTS_VIEW, &matView );
	GDEVICE->SetTransform( D3DTS_PROJECTION, pProject );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	GDEVICE->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_WRAP);
	GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_WRAP );
	
	if( (GMAIN->m_d3dCaps.TextureAddressCaps & D3DPTADDRESSCAPS_MIRROR) == D3DPTADDRESSCAPS_MIRROR )
	{
		GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_MIRROR );
		GDEVICE->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_MIRROR );
	}
	
	// Always pass Z-test, so we can avoid clearing color and depth buffers
	GDEVICE->SetRenderState( D3DRS_ZFUNC, D3DCMP_ALWAYS );
	
	GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);
	SAFE_RENDER(	GMAIN->m_pGrid		);
	SAFE_RENDER(	GMAIN->m_pField	);
	SAFE_RENDER(	GMAIN->m_pTree		);
	
	GDEVICE->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );
	
	return S_OK;
}