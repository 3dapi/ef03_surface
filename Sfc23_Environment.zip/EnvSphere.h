// Interface for the CEnvSphere class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ENVSPHERE_H_
#define _ENVSPHERE_H_

class CEnvSphere
{
protected:
    D3DXMATRIX m_mtWld;
    
    
    CD3DMesh* m_pShinyTeapot;
    LPDIRECT3DVERTEXBUFFER9	m_pVB;
    LPDIRECT3DINDEXBUFFER9	m_pIB;

	DWORD					m_iNvx;
	DWORD					m_iNix;


    ID3DXRenderToEnvMap*	m_pRenderToEnvMap;
    IDirect3DCubeTexture9*	m_pCubeMap;
    IDirect3DTexture9*		m_pSphereMap;

	INT						m_nType;
	
public:
	CEnvSphere();
	virtual ~CEnvSphere();
	
	INT		Init();
	void	Destroy();
	
	INT		Restore();
	void	Invalidate();
	
	INT		FrameMove();
	void	Render();
	
	HRESULT RenderSceneIntoEnvMap();
    HRESULT RenderScene(D3DXMATRIX* pView, D3DXMATRIX* pProject);
};

#endif