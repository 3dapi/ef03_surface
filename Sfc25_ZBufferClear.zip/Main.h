// Main.h: interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


#define NUM_TREES 500
#define NUMTREETEXTURES 3


struct TREEVERTEX
{
	D3DXVECTOR3 p;      // Vertex position
	DWORD       color;  // Vertex color
	FLOAT       tu, tv; // Vertex texture coordinates
	
	enum { FVF =(D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1),};
};


// Desc: Simple structure to hold data for rendering a tree
struct Tree
{
	TREEVERTEX  v[4];           // Four corners of billboard quad
	D3DXVECTOR3 vPos;           // Origin of tree
	DWORD       dwTreeTexture;  // Which texture map to use
	DWORD       dwOffset;       // Offset into vertex buffer of tree's vertices
};





class CMain : public CD3DApplication
{
	LPD3DXFONT	m_pD3DXFont;              // Font for drawing text
	CD3DMesh*	m_pTerrain;           // Terrain object
	CD3DMesh*	m_pSkyBox;            // Skybox background object
	
	LPDIRECT3DVERTEXBUFFER9 m_pTreeVB;  // Vertex buffer for rendering a tree
	LPDIRECT3DTEXTURE9      m_pTreeTextures[NUMTREETEXTURES]; // Tree images
	D3DXMATRIX    m_matBillboardMatrix; // Used for billboard orientation
	Tree          m_Trees[NUM_TREES];   // Array of tree info
	
	D3DXVECTOR3   m_vEyePt;             // Camera position
	
	BOOL    IsTreePositionValid( DWORD );
	HRESULT DrawBackground();
	HRESULT DrawTrees();
	
protected:
	HRESULT OneTimeSceneInit();
	HRESULT InitDeviceObjects();
	HRESULT RestoreDeviceObjects();
	HRESULT InvalidateDeviceObjects();
	HRESULT DeleteDeviceObjects();

	HRESULT Render();
	HRESULT FrameMove();
	
public:
	CMain();
	
	CMcPostBuf		m_Rf1;
	CMcPostBuf		m_Rf2;
	
	ID3DXSprite*	m_pSprite;
};


#endif

