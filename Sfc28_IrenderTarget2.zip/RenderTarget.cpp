// Implementation of the IrenderTarget class.
//
//////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>


#include "RenderTarget.h"


IrenderTarget::~IrenderTarget()
{
}



#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }



class CrenderTarget : public IrenderTarget
{
protected:
	LPDIRECT3DDEVICE9		m_pDev	;		// Device
	D3DCAPS9				m_Caps	;

	INT						m_nType	;		// 0: ID3DXRenderToSurface, 1: ID3DXRenderToEnvMap(Sphere) 2: CubeMap

	INT						m_iW	;		// Width
	INT						m_iH	;		// Height
	DWORD					m_dD	;		// Depth Format

	LPD3DXRENDERTOSURFACE	m_pRts	;		// Direct3D Render To Target
	LPD3DXRenderToEnvMap	m_pRte	;		// Direct3D Render To Environment Map

	LPDIRECT3DTEXTURE9		m_pTxP	;		// Plan or Sphere Map Texture
	LPDIRECT3DSURFACE9		m_pSfc	;		// Rendering�� �ؽ�ó surface

	IDirect3DCubeTexture9*	m_pTxC	;		// Cube Map Texture
	IDirect3DCubeTexture9*	m_pCubeMap;

	D3DXMATRIX				m_mtWld;
	D3DXMATRIX				m_mtPrj;

public:
	CrenderTarget();
	virtual ~CrenderTarget();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	void	Destroy();

	virtual	INT		OnResetDevice();
	virtual	INT		OnLostDevice();

	virtual	INT		BeginScene(DWORD dClearMode = (0x1L|0x2L|0x4L), DWORD dClearColor = 0xFF006699);
	virtual	INT		EndScene();

	virtual	INT		GetWidth();
	virtual	INT		GetHeight();
	virtual	DWORD	GetDepth();

	virtual	void*	GetTexture() const;
	virtual	void*	GetSurface() const;

protected:
	INT		CreateRenderSurface();
	void	GetCubeMapViewMatrix(D3DXMATRIX* pOut, DWORD dwFace);

	INT		RenderScene(D3DXMATRIX *pView);
	INT		RenderSceneIntoEnvMap();
};



CrenderTarget::CrenderTarget()
{
	m_nType	= 0;
	m_iW	= -1;
	m_iH	= -1;
	m_dD	= 0xFFFFFFFF;

	m_pDev	= NULL;
	
	m_pRts	= NULL;
	m_pRte	= NULL;

	m_pTxP	= NULL;
	m_pSfc	= NULL;
}


CrenderTarget::~CrenderTarget()
{
	Destroy();
}


INT CrenderTarget::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	m_iW	= (INT )p2;
	m_iH	= (INT )p3;
	m_nType	= (INT )p4;


	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixPerspectiveFovLH( &m_mtPrj, D3DX_PI * 0.5f, 1.0f, .1f, 5000.0f );

	return CreateRenderSurface();
}



INT CrenderTarget::CreateRenderSurface()
{
	HRESULT hr=-1;

	DWORD				dMip = 1;
	LPDIRECT3DSURFACE9	pSfC = NULL;
	LPDIRECT3DSURFACE9	pSfD = NULL;
	D3DSURFACE_DESC		dscC;
	D3DSURFACE_DESC		dscD;

	D3DCAPS9			m_Caps;

	m_pDev->GetRenderTarget(0,&pSfC);
	m_pDev->GetDepthStencilSurface(&pSfD);

    pSfC->GetDesc(&dscC);
	pSfD->GetDesc(&dscD);

	m_pDev->GetDeviceCaps(&m_Caps);

	pSfC->Release();
	pSfD->Release();

	if(m_iW<0)
		m_iW = dscC.Width;
	
	if(m_iH<0)
		m_iH = dscC.Height;

	if(0==m_nType)
		hr = D3DXCreateRenderToSurface(m_pDev
							, m_iW
							, m_iH
							, dscC.Format
							, TRUE
							, dscD.Format
							, &m_pRts);

	else
		hr = D3DXCreateRenderToEnvMap(m_pDev
							, m_iW
							, dMip
							, dscC.Format
							, TRUE
							, dscD.Format
							, &m_pRte);

	if(2 == m_nType && !(m_Caps.TextureCaps & D3DPTEXTURECAPS_CUBEMAP) )
		m_nType = 1;


	if(0==m_nType)
		hr = D3DXCreateTexture(m_pDev
							, m_iW
							, m_iH
							, dMip
							, D3DUSAGE_RENDERTARGET
							, dscC.Format
							, D3DPOOL_DEFAULT
							, &m_pTxP);

	// Create the cubemap, with a format that matches the backbuffer
	// Create the spheremap, with a format that matches the backbuffer
	else if(1==m_nType)
		hr = D3DXCreateTexture(m_pDev
							, m_iW
							, m_iW
							, dMip
							, D3DUSAGE_RENDERTARGET
							, dscC.Format
							, D3DPOOL_DEFAULT
							, &m_pTxP );
	else if(2==m_nType)
		hr = D3DXCreateCubeTexture( m_pDev
							, m_iW
							, dMip
							, D3DUSAGE_RENDERTARGET
							, dscC.Format
							, D3DPOOL_DEFAULT
							, &m_pTxC );
		
    if(FAILED(hr))
        return -1;


	if(0==m_nType || 1== m_nType)
	{
		hr = m_pTxP->GetSurfaceLevel(0, &m_pSfc);
		m_dD = (D3DFORMAT)dscD.Format;
	}

	return hr;
}


void CrenderTarget::Destroy()
{
	SAFE_RELEASE(	m_pSfc	);
	SAFE_RELEASE(	m_pTxP	);
	SAFE_RELEASE(	m_pRts	);
	SAFE_RELEASE(	m_pRte	);
}


INT CrenderTarget::OnResetDevice()
{
	if(NULL == m_pRts && NULL == m_pRte )
		return CreateRenderSurface();

	return 0;
}

INT CrenderTarget::OnLostDevice()
{
	Destroy();

	return 0;
}


INT CrenderTarget::BeginScene(DWORD dClearMode, DWORD dClearColor)
{
	HRESULT hr = -1;
	
	if(0==m_nType)
	{
		hr = m_pRts->BeginScene(m_pSfc, NULL);

		if(0xFFFFFFFF != dClearMode)
			hr = m_pDev->Clear( 0L, NULL, dClearMode, dClearColor, 1.0f, 0L );
	}

	else
	{
		D3DXMATRIX mtOldWld;
		D3DXMATRIX mtOldViw;
		D3DXMATRIX mtOldPrj;

		m_pDev->GetTransform(D3DTS_WORLD, &mtOldWld);
		m_pDev->GetTransform(D3DTS_VIEW, &mtOldViw);
		m_pDev->GetTransform(D3DTS_PROJECTION, &mtOldPrj);

		D3DXMATRIX matViewDir = mtOldViw;
					
		// Always pass Z-test, so we can avoid clearing color and depth buffers
		m_pDev->SetRenderState( D3DRS_ZFUNC, D3DCMP_ALWAYS );
		m_pDev->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );

		if(1 == m_nType)
			hr = m_pRte->BeginSphere( m_pTxP );
		else if(2 == m_nType)
			hr = m_pRte->BeginCube( m_pTxC );


		m_pDev->SetTransform(D3DTS_WORLD, &mtOldWld);
		m_pDev->SetTransform(D3DTS_VIEW, &mtOldViw);
		m_pDev->SetTransform(D3DTS_PROJECTION, &mtOldPrj);
	}

	return hr;
}


INT CrenderTarget::EndScene()
{
	HRESULT hr = -1;

	if(0 == m_nType)
		hr = m_pRts->EndScene( 0 );

	else
		hr = m_pRte->End( 0 );

	return hr;
}



INT CrenderTarget::RenderSceneIntoEnvMap()
{
	HRESULT hr;

	D3DXMATRIX matViewDir;
	m_pDev->GetTransform(D3DTS_VIEW, &matViewDir);

	for( UINT i = 0; i < 6; i++ )
	{
		hr = m_pRte->Face( (D3DCUBEMAP_FACES) i, 0 );
		
		// Set the view transform for this cubemap surface
		D3DXMATRIX matView;
		GetCubeMapViewMatrix(&matView, (D3DCUBEMAP_FACES) i );
		D3DXMatrixMultiply( &matView, &matViewDir, &matView );
		
		RenderScene( &matView);
	}
	
	hr = m_pRte->End( 0 );

	return hr;
}





INT CrenderTarget::RenderScene(D3DXMATRIX *pView)
{
	m_pDev->SetTransform( D3DTS_WORLD, &m_mtWld );
	m_pDev->SetTransform( D3DTS_VIEW, pView );
	m_pDev->SetTransform( D3DTS_PROJECTION, &m_mtPrj );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	m_pDev->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	m_pDev->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	
	m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_WRAP );
	
	if( (m_Caps.TextureAddressCaps & D3DPTADDRESSCAPS_MIRROR) == D3DPTADDRESSCAPS_MIRROR )
	{
		m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_MIRROR );
		m_pDev->SetSamplerState( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_MIRROR );
	}
	
	// Always pass Z-test, so we can avoid clearing color and depth buffers
	m_pDev->SetRenderState( D3DRS_ZFUNC, D3DCMP_ALWAYS );
	
	m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L);
	

	
	//GMAIN->RenderScene();
	
	m_pDev->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );
	
	return 0;
}









void CrenderTarget::GetCubeMapViewMatrix(D3DXMATRIX* pOut, DWORD dwFace )
{
    D3DXVECTOR3 vEyePt   = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vLookDir;
    D3DXVECTOR3 vUpDir;

    switch( dwFace )
    {
        case D3DCUBEMAP_FACE_POSITIVE_X:
            vLookDir = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_X:
            vLookDir = D3DXVECTOR3(-1.0f, 0.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_POSITIVE_Y:
            vLookDir = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_Y:
            vLookDir = D3DXVECTOR3( 0.0f,-1.0f, 0.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
            break;
        case D3DCUBEMAP_FACE_POSITIVE_Z:
            vLookDir = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
        case D3DCUBEMAP_FACE_NEGATIVE_Z:
            vLookDir = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
            vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
            break;
    }

    // Set the view transform for this cubemap surface
	D3DXMatrixLookAtLH( pOut, &vEyePt, &vLookDir, &vUpDir );
}









INT CrenderTarget::GetWidth()
{
	return m_iW;
}

INT CrenderTarget::GetHeight()
{
	return m_iH;
}


DWORD CrenderTarget::GetDepth()
{
	return m_dD;
}


void* CrenderTarget::GetTexture() const
{
	return m_pTxP;
}


void* CrenderTarget::GetSurface() const
{
	return m_pSfc;
}





INT LcD3D_CreateRenderTarget(char* sCmd, IrenderTarget** pData, void* pDevice, INT iWidth, INT iHeight)
{
	*pData = NULL;

	CrenderTarget*	p = new CrenderTarget;

	INT	nType = 0;
	
	if(sCmd && 0 == _stricmp("Sphere", sCmd))
		nType	= 1;

	if(sCmd && 0 == _stricmp("Cube", sCmd))
		nType	= 2;


	if(FAILED(p->Create(pDevice, (void*)iWidth, (void*)iHeight, (void*)nType)))
	{
		delete p;
		return -1;
	}

	*pData = p;

	return 0;
}



