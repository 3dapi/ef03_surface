// Interface for the CEfSurface class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _EfSurface_H_
#define _EfSurface_H_


typedef D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef LPDIRECT3DSURFACE9					PDSF;
typedef LPD3DXRENDERTOSURFACE				PDRS;

class CEfSurface
{
public:
	struct VtxwDUV
	{
		VEC4	p;
		DWORD	d;
		FLOAT	u,v;

		VtxwDUV()	{}
		VtxwDUV(FLOAT X,FLOAT Y,FLOAT Z,FLOAT U,FLOAT V,DWORD D=0xFFFFFFFF) : p(X,Y,Z,1.F),u(U),v(V),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)};
	};

protected:
	PDEV		m_pDev;

	PDTX		m_pTx;			// Target Texture
	PDSF		m_pTxSf;		// Target Surface	
	PDRS		m_pTxRs;		// Render To Surface

	INT			m_iTxW;			// Render Target Texture Width

	VtxwDUV		m_pVtx[4];

public:
	CEfSurface();
	virtual ~CEfSurface();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif