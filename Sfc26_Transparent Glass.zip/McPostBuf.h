// McPostBuf.h: interface for the CMcPostBuf class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _McPostBuf_H_
#define _McPostBuf_H_


class CMcPostBuf
{
protected:
	INT					nTxW;		// Width
	INT					nTxH;		// Height
	INT					nTxD;		// Depth

	DWORD				dFmtC;		// Color buffer Format
	DWORD				dFmtD;		// Depth buffer Format

	LPDIRECT3DDEVICE9	pDev;
	LPDIRECT3DSURFACE9	pDevC;
	LPDIRECT3DSURFACE9	pDevD;


	LPDIRECT3DTEXTURE9	pTxC;		// Texture of Color buffer
	LPDIRECT3DSURFACE9	pSfC;		// Surface of Color buffer

	LPDIRECT3DSURFACE9	pSfD;		// Surface of Depth buffer

public:	
	CMcPostBuf();
	virtual ~CMcPostBuf();
	
	INT		Create(LPDIRECT3DDEVICE9 _pDev, INT _nTxW, INT _nTxH);
	void	Destroy();

	INT		BeginScene();
	INT		EndScene();

	LPDIRECT3DTEXTURE9 GetTexture();
};

#endif


