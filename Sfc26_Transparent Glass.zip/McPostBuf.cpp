// McPostBuf.cpp: implementation of the CMcPostBuf class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <D3DX9.h>

#include "McPostBuf.h"


CMcPostBuf::CMcPostBuf()
{
	nTxW	= 0;
	nTxH	= 0;
	nTxD	= 0;
	
	dFmtC	= 0;
	dFmtD	= 0;
	
	pDev	= NULL;
	pDevC	= NULL;
	pDevD	= NULL;
	
	pTxC	= NULL;
	
	pSfC	= NULL;
	pSfD	= NULL;
	
}


CMcPostBuf::~CMcPostBuf()
{
	Destroy();
}


INT CMcPostBuf::Create(LPDIRECT3DDEVICE9 _pDev
			   , INT _nTxW				// Texture Width
			   , INT _nTxH				// Texture Height
			   )
{
	HRESULT hr=-1;
	pDev	= _pDev;
	nTxW	= _nTxW;
	nTxH	= _nTxH;
	
	hr = D3DXCreateTexture(pDev
		, nTxW
		, nTxH
		, 1
		, D3DUSAGE_RENDERTARGET
		, D3DFMT_X8R8G8B8
		, D3DPOOL_DEFAULT
		, &pTxC);
	
	if(FAILED(hr))
		return -1;
	
	if(FAILED(pTxC->GetSurfaceLevel(0, &pSfC)))
		return -1;
	
	
	
	if(FAILED(pDev->GetRenderTarget(0, &pDevC)))
		return -1;
	
	if(FAILED(pDev->GetDepthStencilSurface(&pDevD)))
		return -1;
	
	
	D3DSURFACE_DESC dsc;
	pDevD->GetDesc(&dsc);
	
	
	if( FAILED(pDev->CreateDepthStencilSurface(
		nTxW
		, nTxH
		, dsc.Format
		, D3DMULTISAMPLE_NONE
		, 0
		, TRUE
		, &pSfD
		, NULL ) ) )
		return -1;
	
	return 0;
}

void CMcPostBuf::Destroy()
{
	if(pDevC)
	{
		pDevC->Release();
		pDevC = NULL;
	}
	
	if(pDevD)
	{
		pDevD->Release();
		pDevD = NULL;
	}
	
	
	if(pTxC)
	{
		pTxC->Release();
		pTxC = NULL;
	}
	
	
	if(pSfC)
	{
		pSfC->Release();
		pSfC = NULL;
	}
	
	if(pSfD)
	{
		pSfD->Release();
		pSfD = NULL;
	}
}

INT CMcPostBuf::BeginScene()
{
	pDev->SetRenderTarget(0, pSfC);
	pDev->SetDepthStencilSurface(pSfD);
	
	return 0;
}

INT CMcPostBuf::EndScene()
{
	pDev->SetRenderTarget(0, pDevC);
	pDev->SetDepthStencilSurface(pDevD);
	
	return 0;
}


LPDIRECT3DTEXTURE9 CMcPostBuf::GetTexture()
{
	return pTxC;
}

