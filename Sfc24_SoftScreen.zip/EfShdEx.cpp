// Implementation of the CEfShdEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


INT		LnD3D_DeviceFormat(LPDIRECT3DDEVICE9 pDev, DWORD* FMTColor, DWORD* FMTDepthStencil=NULL, UINT* Width=NULL, UINT* Height=NULL)
{
	LPDIRECT3DSURFACE9 pSf1		= NULL;
	LPDIRECT3DSURFACE9 pSf2		= NULL;

	D3DSURFACE_DESC	dsc1;
	D3DSURFACE_DESC	dsc2;

	if(FAILED(pDev->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pSf1)))
		return -1;

	if(FAILED(pSf1->GetDesc(&dsc1)))
		return -1;

	pSf1->Release();


	if(FAILED(pDev->GetDepthStencilSurface(&pSf2)))
		return -1;

	if(FAILED(pSf2->GetDesc(&dsc2)))
		return -1;

	pSf2->Release();

	if(FMTColor)
		*FMTColor = dsc1.Format;

	if(FMTDepthStencil)
		*FMTDepthStencil = dsc2.Format;

	if(Width)
		*Width = dsc1.Width;

	if(Height)
		*Height = dsc1.Height;

	return 1;
}



CEfShdEx::CEfShdEx()
{
	m_iTxW		= g_pApp->m_dwCreationWidth *1;
	m_iTxH		= g_pApp->m_dwCreationHeight*1;

	m_nTxN		= 3;


	for(int i=0; i<m_nTxN; ++i)
		m_pRS[i]	= NULL;
}

CEfShdEx::~CEfShdEx()
{
	Destroy();	
}


INT CEfShdEx::Create(void* p1, void* p2, void* p3)
{
	m_pDev = (LPDIRECT3DDEVICE9)p1;

	if(FAILED(this->Restore()))
		return -1;

	return 1;
}

void CEfShdEx::Destroy()
{
}


INT CEfShdEx::Restore()
{
	HRESULT hr;


	if(m_pRS[0])
		return 1;

	for(int i=0; i<m_nTxN; ++i)
	{
		int nW = m_iTxW>>(i+1);
		int nH = m_iTxH>>(i+1);

		hr = D3DXCreateTexture(m_pDev, nW, nH, 1
						, D3DUSAGE_RENDERTARGET
						, D3DFMT_X8R8G8B8
						, D3DPOOL_DEFAULT
						, &m_RndSf[i].pTx);

		m_RndSf[i].pTx->GetSurfaceLevel(0, &m_RndSf[i].pSf);


		D3DSURFACE_DESC desc;
		m_RndSf[i].pSf->GetDesc(&desc);

		DWORD	dFmtDepth;

		LnD3D_DeviceFormat(m_pDev, NULL, &dFmtDepth);

		if(FAILED(D3DXCreateRenderToSurface(m_pDev, desc.Width, desc.Height, desc.Format, TRUE, (D3DFORMAT)dFmtDepth, &m_pRS[i])))
			return -1;
	}

	return 1;
}

void CEfShdEx::Invalidate()
{
	for(int i=0; i<m_nTxN; ++i)
	{
		m_RndSf[i].Invalidate();
		SAFE_RELEASE(m_pRS[i]);
	}
}


INT CEfShdEx::FrameMove()
{
	for(int i=0; i<m_nTxN; ++i)
	{
		m_pRS[i]->BeginScene(m_RndSf[i].pSf, NULL);

		m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER, 0x00006688, 1.0f, 0L );

		g_pApp->RenderScene();
		
		m_pRS[i]->EndScene( 0 );
	}

	return 1;
}

void CEfShdEx::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
		
	m_pDev->SetFVF(CEfShdEx::VtxwDUV1::FVF);

	INT	i=0;	
	FLOAT fX0 = 0;
	FLOAT fY0 = 0;
	FLOAT fX1 = (FLOAT)m_iTxW;
	FLOAT fY1 = (FLOAT)m_iTxH;

	m_pVtx[0] = CEfShdEx::VtxwDUV1( fX0, fY0, 0.f, 1.f, 0.f, 0.f, 0xFFFFFFFF);
	m_pVtx[1] = CEfShdEx::VtxwDUV1( fX1, fY0, 0.f, 1.f, 1.f, 0.f, 0xFFFFFFFF);
	m_pVtx[2] = CEfShdEx::VtxwDUV1( fX0, fY1, 0.f, 1.f, 0.f, 1.f, 0xFFFFFFFF);
	m_pVtx[3] = CEfShdEx::VtxwDUV1( fX1, fY1, 0.f, 1.f, 1.f, 1.f, 0xFFFFFFFF);

	FLOAT	fEpsilon = 3.5f;


	for(i=0; i<m_nTxN; ++i)
	{
		D3DXCOLOR xclr(1,1,1, 1);

		xclr *= 1.f/m_nTxN;
		xclr.a = 1.f/(  (1.f+i)* m_nTxN);

		m_pVtx[0].d = xclr;
		m_pVtx[1].d = xclr;
		m_pVtx[2].d = xclr;
		m_pVtx[3].d = xclr;

		m_pVtx[0].p.x += -fEpsilon * i;
		m_pVtx[0].p.y += -fEpsilon * i;

//		m_pVtx[1].p.x += -fEpsilon * i;
		m_pVtx[1].p.y += -fEpsilon * i;

		m_pVtx[2].p.x += -fEpsilon * i;
//		m_pVtx[2].p.y += -fEpsilon * i;

//		m_pVtx[3].p.x += -fEpsilon * i;
//		m_pVtx[3].p.y += -fEpsilon * i;
		
		m_pDev->SetTexture( 0, m_RndSf[i].pTx);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVtx, sizeof(CEfShdEx::VtxwDUV1));
	}


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);


// FOR Test
//	fX1 = 200;
//	fY1 = 150;
//
//	for(i=0; i<m_nTxN; ++i)
//	{
//		m_pVtx[0] = CEfShdEx::VtxwDUV1( fX0, 100+fY1*(i+0), 0.f, 1.f, 0.f, 0.f, 0xFFFFFFFF);
//		m_pVtx[1] = CEfShdEx::VtxwDUV1( fX1, 100+fY1*(i+0), 0.f, 1.f, 1.f, 0.f, 0xFFFFFFFF);
//		m_pVtx[2] = CEfShdEx::VtxwDUV1( fX0, 100+fY1*(i+1), 0.f, 1.f, 0.f, 1.f, 0xFFFFFFFF);
//		m_pVtx[3] = CEfShdEx::VtxwDUV1( fX1, 100+fY1*(i+1), 0.f, 1.f, 1.f, 1.f, 0xFFFFFFFF);
//
//		m_pDev->SetTexture( 0, m_RndSf[i].pTx);
//		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVtx, sizeof(CEfShdEx::VtxwDUV1));
//	}
}



