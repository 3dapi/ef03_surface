// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


#pragma once


#define NUMTREETEXTURES 3
#define NUM_TREES 500


struct TREEVERTEX
{
    D3DXVECTOR3 p;      // Vertex position
    DWORD       color;  // Vertex color
    FLOAT       tu, tv; // Vertex texture coordinates

    enum { FVF = (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1), };
};



struct Tree
{
    TREEVERTEX  v[4];           // Four corners of billboard quad
    D3DXVECTOR3 vPos;           // Origin of tree
    DWORD       dwTreeTexture;  // Which texture map to use
    DWORD       dwOffset;       // Offset into vertex buffer of tree's vertices
};



class CMain : public CD3DApplication
{

protected:
	CD3DMesh*     m_pTerrain;           // Terrain object
    CD3DMesh*     m_pSkyBox;            // Skybox background object

    LPDIRECT3DVERTEXBUFFER9	m_pTreeVB;  // Vertex buffer for rendering a tree
    LPDIRECT3DTEXTURE9		m_pTreeTextures[NUMTREETEXTURES]; // Tree images
    D3DXMATRIX				m_matBillboardMatrix; // Used for billboard orientation
    Tree					m_Trees[NUM_TREES];   // Array of tree info

    D3DXVECTOR3				m_vEyePt;             // Camera position

    BOOL    IsTreePositionValid( DWORD );
    HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT, D3DFORMAT );
    HRESULT DrawBackground();
    HRESULT DrawTrees();


protected:
    ID3DXFont*              m_pD3DXFont;            // D3DX font    

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT FinalCleanup();

    virtual HRESULT Init();
    virtual HRESULT Destroy();
	
    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

	HRESULT RenderText();


public:
	CMain();
    LRESULT		MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	INT			RenderScene();

	CEfShdEx*	m_pShader	;
};


extern CMain* g_pApp;

#endif



