// Interface for the CEfShdEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EfShdEx_H_
#define _EfShdEx_H_


struct McRndSf
{
	LPDIRECT3DTEXTURE9	pTx;
	LPDIRECT3DSURFACE9	pSf;

	McRndSf()
	{
		pTx	= NULL;
		pSf	= NULL;
	}

	void Invalidate()
	{
		SAFE_RELEASE(	pTx	);
		SAFE_RELEASE(	pSf	);
	}
};


class CEfShdEx
{
public:
	struct VtxwDUV1
	{
		D3DXVECTOR4	p;
		DWORD	d;
		FLOAT	u0,v0;

		VtxwDUV1()	{}
		VtxwDUV1(FLOAT X,FLOAT Y,FLOAT Z,FLOAT W,FLOAT U0,FLOAT V0, DWORD D=0x40FFFFFF):p(X,Y,Z,W),u0(U0),v0(V0), d(D){}
		enum	{FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};


protected:
	LPDIRECT3DDEVICE9		m_pDev		;
	
	INT			m_nTxN		;
	LPD3DXRENDERTOSURFACE		m_pRS[8]	;
	McRndSf		m_RndSf[8]	;
	INT			m_iTxW		;													// Texture Size
	INT			m_iTxH		;													// Texture Size

	VtxwDUV1	m_pVtx[4]	;
	

public:
	CEfShdEx();
	virtual ~CEfShdEx();
	
	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();
};


#endif
