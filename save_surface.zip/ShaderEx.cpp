// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;

	m_pFVF	= NULL;
	m_pEft	= NULL;
	
	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HWND	hWnd;
	HRESULT	hr=0;

	m_pDev	= pDev;

	////////////////////////////////////////////////////////////////////////////
	// Base Code
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);

	hWnd = ppm.hFocusWindow;

	m_pVtx[0] = VtxDUV1(-1.0F, 1.0F,  0.0F,  0.0F, 0.0F, D3DXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) );
	m_pVtx[1] = VtxDUV1( 1.0F, 1.0F,  0.0F,  1.0F, 0.0F, D3DXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[2] = VtxDUV1( 1.0F,-1.0F,  0.0F,  1.0F, 1.0F, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[3] = VtxDUV1(-1.0F,-1.0F,  0.0F,  0.0F, 1.0F, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );

	m_pVtx[0] = VtxDUV1(-0.9F, 0.9F,  0.0F,  0.0F, 0.0F, D3DXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) );
	m_pVtx[1] = VtxDUV1( 0.9F, 0.9F,  0.0F,  1.0F, 0.0F, D3DXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[2] = VtxDUV1( 0.9F,-0.9F,  0.0F,  1.0F, 1.0F, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[3] = VtxDUV1(-0.9F,-0.9F,  0.0F,  0.0F, 1.0F, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );

	DWORD dwFlags = 0;
	LPD3DXBUFFER	pErr	= NULL;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	// �ڵ� ������
	hr = D3DXCreateEffectFromFile(	m_pDev
									,	"data/Shader.fx"
									,	NULL
									,	NULL
									,	dwFlags
									,	0
									,	&m_pEft
									,	&pErr);
	
	if ( FAILED(hr) )
	{
		if(pErr)
		{
			MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", 0);
			pErr->Release();	pErr = NULL;
		}

		return -1;
	}

	// ���� ������
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;

	//
	////////////////////////////////////////////////////////////////////////////




	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pEft	);
}


INT CShaderEx::Restore()
{
	return m_pEft->OnResetDevice();
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	static D3DXMATRIX mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);
	HRESULT	hr = 0;

	// ��ȯ ����� �ʱ�ȭ
	////////////////////////////////////////////////////////////////////////////
	// for Test

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP  , D3DTOP_MODULATE);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	for(int i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}

	// �����Լ� ���������ο��� �̹����� ��µǴ� �� Ȯ��
	//	m_pDev->SetTexture(0, m_pTex);
	//	m_pDev->SetFVF(VtxDUV1::FVF);
	//	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	//
	////////////////////////////////////////////////////////////////////////////


	////////////////////////////////////////////////////////////////////////////
	//����

	UINT	nPass = 0;
	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pEft->SetTechnique("Tech");

	m_pEft->SetTexture("m_TxDif", m_pTex);

	m_pEft->Begin(&nPass, 0);
	m_pEft->BeginPass(0);

		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);

	// ����
	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
	
}





void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTex = pTx;
}


